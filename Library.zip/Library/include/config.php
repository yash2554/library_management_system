<?php
//error_reporting(E_ALL);

define("BASE_URL",'http://localhost:8080/Library/');
define("BASE_DIR",dirname(dirname($_SERVER['SCRIPT_FILENAME'])));
define("SITE_NAME",'Library');
define("LOGO_URL",BASE_URL.'images/logo.png');
define("COMMON_URL",'//localhost:8080/Library/');
define("SECURE_URL",'http://localhost:8080/Library/');
define("KEY", '12474ee1d8eb8312b43464983e7c38c8');
define("CSV_URL",BASE_DIR.'/tmp/uploadcsv/');

//defines the database username and password for central db
define("DB_HOST", "127.0.0.1");
define("DB_USER_NAME", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "library");
define("TBL_PREFIX", "");



/****** LOGGER ******/
$logger_config = array(
                        'appenders' => array(

                            'default' => array(
                                'class' => 'LoggerAppenderNull'
                            ),
                            'request' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - FROM:%server{REMOTE_ADDR} - REQUEST:[%request] - %M %n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiin/request/request.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            ),
                            'response' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - FROM:%server{REMOTE_ADDR} - REQUEST:[%request] - %M %n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiin/response/response.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            ),
                            'v_response' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - %M %n==========================%n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiout/response/response.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            )
                        ),
                        'rootLogger' => array(
                            'appenders' => array('default')
                        ),
                        'loggers' => array(
                            'rlog' => array(
                                'appenders' => array('request')
                            ),
                            'res_log' => array(
                                'appenders' => array('response')
                            ),
                            'vendor_res' => array(
                                'appenders' => array('v_response')
                            )
                        )
    				);
