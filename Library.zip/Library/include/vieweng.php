<?php
if($obj->view=='ajax' ||  $obj->render==FALSE)
{
    exit;
}
$langcode = 'en';
if($obj->view!='default')
{
    $controller = $obj->view;
}
if(file_exists(VIEW_PATH.DS.'lang'.DS.$langcode.'.php'))
{
    require_once (VIEW_PATH.DS.'lang'.DS.$langcode.'.php');
}
else
{
    print_r('Missing View Language File');
}

##Include Header of View
if(file_exists(VIEW_PATH.DS.$controller.DS.'header.php'))
{
    require_once (VIEW_PATH.DS.$controller.DS.'header.php');
}
else
{
    require_once (VIEW_PATH.DS.'header.php');
}

##Include main View
if(file_exists(VIEW_PATH.DS.$controller.DS.$action.'.php'))
{
    require_once (VIEW_PATH.DS.$controller.DS.$action.'.php');
}
else
{
    print_r('Missing View for action:'.$action);
}

##Include Footer View
if(file_exists(VIEW_PATH.DS.$controller.DS.'footer.php'))
{
    require_once (VIEW_PATH.DS.$controller.DS.'footer.php');
}
else
{
    require_once (VIEW_PATH.DS.'footer.php');
}