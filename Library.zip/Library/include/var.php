<?php
define('INCLUDE_PATH', ROOT .DS . 'include'.DS);
define('CORE_PATH', ROOT .DS.'core'.DS);
define('MODEL_PATH', ROOT .DS.'app'.DS. 'models'.DS);
define('CONTROLLER_PATH', ROOT .DS.'app'.DS. 'controllers'.DS);
define('VIEW_PATH', ROOT .DS.'app'.DS. 'views'.DS);
define('LOG_PATH', ROOT .DS.'tmp'.DS.'logs'.DS);
define('LOGGER_PATH', INCLUDE_PATH.DS.'logger'.DS);
define("FRONT_PAGGING_STYLE", "3");


//Table variables
define('TBL_ADMIN', 'admin');
define('TBL_AUTHOR', 'author');
define('TBL_BOOK', 'book');
define('TBL_BOOK_PUB', 'book_pub');
define('TBL_BORROW', 'borrow');
define('TBL_BRANCH', 'branch');
define('TBL_BRANCH_BOOK', 'branch_book');
define('TBL_PUBLISHER', 'publisher');
define('TBL_READER', 'reader');


define('TBL_MENU', TBL_PREFIX.'menu');


/****** LOGGER ******/
$logger_config = array(
                        'appenders' => array(

                            'default' => array(
                                'class' => 'LoggerAppenderNull'
                            ),
                            'request' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - FROM:%server{REMOTE_ADDR} - REQUEST:[%request] - %M %n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiin/request/request.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            ),
                            'response' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - FROM:%server{REMOTE_ADDR} - REQUEST:[%request] - %M %n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiin/response/response.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            ),
                            'v_response' => array(
                                'class' => 'LoggerAppenderRollingFile',
                                'layout' => array(
                                    'class' => 'LoggerLayoutPattern',
                                    'params' => array(
                                        'conversionPattern' => '%date - %msg - %M %n==========================%n'
                                    )
                                ),
                                'params' => array(
                                    'file' => BASE_DIR.'/tmp/logs/apiout/response/response.log',
                                    'maxFileSize' => '1MB',
                                    'append' => true,
                                    'maxBackupIndex' => 100,
                                )
                            )
                        ),
                        'rootLogger' => array(
                            'appenders' => array('default')
                        ),
                        'loggers' => array(
                            'rlog' => array(
                                'appenders' => array('request')
                            ),
                            'res_log' => array(
                                'appenders' => array('response')
                            ),
                            'vendor_res' => array(
                                'appenders' => array('v_response')
                            )
                        )
    				);
