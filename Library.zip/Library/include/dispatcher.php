<?php

// Deault currency to USD on Page Load
if(!isset($_SESSION["currency"]))
{
    $_SESSION["currency"] = "USD";
}

if(file_exists(CONTROLLER_PATH.$controller.'Controller.php'))
{
    require_once (CONTROLLER_PATH.DS.$controller.'Controller.php');
    $controllerf= $controller.'Controller';
   // print_r($controllerf);
    $obj = new $controllerf();
    $check = $controller.'-'.$action;
   // print_r($_SESSION['admin']['logged_in']);
    if($controller=='admin')
    {
       // print_r($_SESSION['admin']['logged_in']);
        if(isset($_SESSION['admin']['logged_in']))
        {
            if($_SESSION['admin']['logged_in'] == 0)
            {
                $action = 'login';
            }
        }
        else
        {
            $_SESSION['admin']['logged_in'] = 0;
            $action = 'login';
        }

    }


//    if($controller == 'manageproperty')
//    {
//        if(isset($_SESSION['owner']['logged_in']))
//        {
//
//            if($_SESSION['owner']['logged_in'] == 0 && $action!='reset_password')
//            {
//                $action = 'login';
//            }
//        }
//        else
//        {
//            $_SESSION['owner']['logged_in'] = 0;
//            $action = 'login';
//        }
//
//    }

//    if($controller=='selfpropertyregistration')
//    {
//        if(isset($_SESSION['temp_mgr']['logged_in']))
//        {
//            if($_SESSION['temp_mgr']['logged_in'] == 0 && $action!='generalInfo' && $action!='login' && $action!='emailValidate' && $action!='resetPassword')
//            {
//                $action = 'index';
//            }
//        }
//        else
//        {
//            $_SESSION['temp_mgr']['logged_in'] = 0;
//            $action = 'index';
//        }

//    }
//    if(isset($_SESSION['access']) && !in_array($check, $_SESSION['access']))
//    {
//        $action = 'noAccess';
//    }

   // print_r($action);
    if(method_exists($obj, $action))
    {
        $obj->_before();
        if(!empty($params))
        {
            $template = $obj->$action($params);
        }
        else
        {
            $template = $obj->$action();
        }
      //  $obj->_after($action);
    }
    else
    {
        header("HTTP/1.1 404 Not Found");
        print_r('404');
     //   header("Location: ".BASE_URL."page404/");
        exit();
    }
}
else
{
    header("HTTP/1.1 404 Not Found");
    print_r('404');

   //  header("Location: ".BASE_URL."page404/");
     exit();
}
