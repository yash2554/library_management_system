<?php
echo "OOPS Page Not Found !!!!!!!!!";exit;
?>
<html>
    <head>404 Page</head>
    <body>
        <table border="1" >
            <tr><td>Test</td></tr>
        </table>
    </body>
</html>