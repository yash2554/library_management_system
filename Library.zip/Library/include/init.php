<?php
require_once(CORE_PATH."class.pagging.php");
require_once(CORE_PATH."class.database.php");
require_once(CORE_PATH."class.common.php");

//require_once(MODEL_PATH."menu.class.php");

$dbAccess = new DBAccess(DB_HOST,DB_USER_NAME,DB_PASSWORD,DB_NAME);
$commonFunction = new CommonFunction;