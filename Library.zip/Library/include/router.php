<?php

$routing = array(
	'/admin\/(.*?)\/(.*?)\/(.*)/' => 'admin/\1_\2/\3',
    '/cron\/(.*?)\/(.*?)\/(.*)/' => 'cron/\1_\2/\3',
        //'/manage-property\/(.*?)\/(.*?)\/(.*)/' => 'manage-property/\1_\2/\3',
       // '/user\/(.*?)\/(.*?)\/(.*)/' => 'user/\1/\2/\3',

);

$static_pages = array("contact"=>"contact-us.html","privacy"=>"privacy.html","termscondition"=>"termscondition.html");

function routeURL($url)
{
	global $routing;
	foreach ( $routing as $pattern => $result )
    {
        if ( preg_match( $pattern, $url ) )
        {
            return preg_replace( $pattern, $result, $url );
        }
	}
	return ($url);
}

//print_r($controller);
if(isset($_GET['url']))
{
    $url = routeURL($_GET['url']);
    $urlArr = explode('/', $url);
    if(isset($urlArr[0]) && is_string($urlArr[0]) && !is_null($urlArr[0]) && $urlArr[0]!='')
    {
        $controller = preg_replace('/-/', '', $urlArr[0]);
    }
    else
    {
        $controller = 'admin';
    }
    if(in_array($urlArr[0], $static_pages))
    {
        $controller = 'page';
        $static_action = $urlArr[0];
    }
    array_shift($urlArr);
    if(isset($urlArr[0]) && is_string($urlArr[0]) && !is_null($urlArr[0]) && $urlArr[0]!='')
    {
        $actionArr = explode('-',$urlArr[0]);
        $action='';

        foreach($actionArr as $key => $val)
        {
            if($key==0)
            {
                $action.=$val;
            }
            else
            {
                $action.=ucfirst($val);
            }
        }
    }
    elseif(empty($urlArr[0]) && $controller=='page')
    {
        $action = array_search($static_action, $static_pages);
    }
    else
    {
        $action = 'index';
    }
    array_shift($urlArr);
    $params = $urlArr;
}
else
{
    $controller='admin';
    $action = 'login';
}

//redirect code for SSL
// echo "<pre>";
// print_r($_SERVER);
    if($controller!='book')
    {
        if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on')
        {
            header('Location: '."http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']." ");
            die();
        }
    }
    else
    {
        if(!isset($_SERVER['HTTPS']))
        {
            header('Location: '."https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']." ");
            die();
        }
    }
// print_r(BASE_URL);
// echo "<pre>";
// print_r($_SERVER);
// echo "</pre>";
