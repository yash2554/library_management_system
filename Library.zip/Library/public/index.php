<?php
//echo "test public";
error_reporting(E_ALL);
if(extension_loaded('apc'))
{
    ini_set("apc.enabled", "1");
    ini_set("apc.shm_segments", "1");
    ini_set("apc.shm_size", "64M");
    ini_set("apc.max_file_size", "10M");
    ini_set("apc.stat", "1");
}
define('DS', DIRECTORY_SEPARATOR);
define('ROOT', dirname(dirname(__FILE__)));
//echo 'Root:'.ROOT;
session_save_path(ROOT.DS.'tmp'.DS.'session');
session_start();
date_default_timezone_set('America/Los_Angeles') ;
require_once (ROOT . DS . 'include' . DS . 'config.php');
require_once (ROOT . DS . 'include' . DS . 'var.php');
if(isset($_GET) && !empty($_GET))
{
    $url = $_GET['url'];
}
else
{
    
   $url = "admin/login/";
}
require_once (INCLUDE_PATH . DS . 'router.php');
require_once (INCLUDE_PATH . DS . 'init.php');
require_once (INCLUDE_PATH . DS . 'dispatcher.php');
require_once (INCLUDE_PATH . DS . 'vieweng.php');