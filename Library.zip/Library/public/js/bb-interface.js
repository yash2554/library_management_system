/**
 * Init time
 */
$(function () {
    if ($('#topmenu-time').length) {
        setInterval(function () {bbTime('topmenu-time');}, 1000);
    }
});

/**
 * Run dropdown menu
 */
// function moved to html for speed-up
//$(function () {
//    $('#topmenu-menu > li').bind('mouseover', jsddm_open).bind('mouseout',  jsddm_timer);
//});
$(document).bind('block', jsddm_close);


/**
 * Run list export with advsearch filter 
 */

$(function (){
    $('.list-export').click(function (){        
        $(this).attr('href', $(this).attr('href') + '?' + $('#advsearch form').serialize());
    }); 
});

/**
 * MAIN INIT
 */
$(function() {  
    setTimeout("initFloatHeader(); initTooltips();", 100);  
    initClose();
    
    advSearchInit();
    
    initPopups();
    initList();
    initForms();
    initInputDefault();
    initFocuses();
});

/**
 * Init tooltips / helptips
 */
function initTooltips(obj)
{
    if (!obj) {
        obj = $(document);
    }
    
    obj.find('*[rel=tooltip]').tooltip({
        track: true,
        delay: 100,
        showURL: false,
        bodyHandler: function() { 
            return $('<div />').append($('#'+this.id+'-tooltip').clone().removeClass('tooltip')).html();
        }, 
        fade: false,
        top:10
    });
    obj.find('span[rel=helptip]').tooltip({
        track: true,
        delay: 0,
        showURL: false,
        bodyHandler: function() { 
            return $('<div />').append($('#'+this.id+'-tooltip').clone().removeClass('tooltip')).html();
        }, 
        extraClass:'helptip',
        fade:false
    });
}

/**
 * Handle popup links
 */
function initPopups(obj)
{
    if (!obj) {
        obj = $(document);
    }
    
    obj.find('a[rel*=popup]').each(function () {
        // stop propagation of the event first
        $(this).click(function (event) {
            event.stopPropagation();
            this.blur();
        });
        
        // if handler already set - retreat
        if ($(this).attr('onclick') != undefined)  {
            return this;
        }
        
        // main handler
        $(this).click(function (event) {
            if ($(this).attr('rel').indexOf('delete') != -1) {
                if (!confirm(L['deleteConfirm'])) {
                    return false;
                }
            }
            var info = $(this).attr('rel').match(/popup-(\d+)x(\d+)/);
            if (info != null) {
                winOpen(this.href, info[1], info[2]);
            } else {
                winOpen(this.href);
            }
            return false;
        });
    });
}

/**
 * Handle list / meta
 */
function initList(obj)
{
    if (!obj) {
        obj = $(document);
    }
    
    // find all table-lists
    var list = obj.find('table.list');
    
    _initListColors(list);
    
    // hover / click
    // tr:not(tr[id^=cl_details_]) = for Mutual Settlements
    if ($('table.list:not(table.list-form) > tbody > tr:not(tr[id^=cl_details_])').length) {
        obj.delegate('table.list:not(table.list-form) > tbody > tr:not(tr[id^=cl_details_])', 'hover', function(){
            $(this).toggleClass('row-hover');
        });
        obj.delegate('table.list:not(table.list-form) > tbody > tr:not(tr[id^=cl_details_])', 'click', function(){
            $(this).toggleClass('row-active');
        });
    }
    
    obj.find('.list-meta').each(function () {
        // handle page-go
        $(this).find('.list-meta-pnum').click(function (event) {
            $(this).hide()
                .parent().find('.list-meta-pgo').show()
                .find('input').focus();
        });
        
        // on blur of page-go - hide it
        $(this).find('.list-meta-pgo input').bind('blur', function () {
            $(this).parent().parent().hide()
                .parent('.list-meta').find('.list-meta-pnum').show();
        });
        
        // handle page-ipp
        $(this).find('.list-meta-ipp').click(function (event) {
            $(this).hide()
                .parent().find('.list-meta-ippa').show()
                .find('select').focus();
        });
        
        // on blur of ipp - hide it
        $(this).find('.list-meta-ippa select').bind('blur', function () {
            $(this).parent().parent().hide()
                .parent('.list-meta').find('.list-meta-ipp').show();
        });
        
        // on change of ipp - submit
        $(this).find('.list-meta-ippa select').bind('change', function () {
            $(this).parent().submit();
        });
    });
}

function _initListColors(list)
{
    // color rows
    list.find('> * > tr > td:last-child').addClass('last');
    list.find('> tbody > tr').removeClass('row-1').removeClass('row-2');
    list.find('> tbody > tr:even').addClass('row-1');
    list.find('> tbody > tr:odd').addClass('row-2');
}


/**
 * Handle cols / form / inputs
 */
function initForms(obj)
{
    if (!obj) {
        obj = $(document);
    }
    
    // form containers and columns
    var tmp = obj.find(".cols > tbody > tr");
    tmp.find("> td:first-child").addClass('first');
    tmp.find("> td:last-child").addClass('last');
    
    // form cells
    obj.find('table.form').each(function () {
        var have_cols = $(this).find('> colgroup > col,> col').length;
        $(this).find('> tbody > tr').each(function () {
            var label = 'label';
            var value = 'value';
            if (!have_cols) {
                if ($(this).find('> td').length == 1) {
                    label = 'single';
                } else if ($(this).find('> td').length == 2) {
                    label += ' label2';
                    value += ' value2';
                } else if ($(this).find('> td').length == 4) {
                    label += ' label4';
                    value += ' value4';
                }
            }
            $(this).find('> td:even:not(.label):not(.value):not(.buttons)').addClass(label);
            $(this).find('> td:odd:not(.label):not(.value):not(.buttons)').addClass(value);
        });
    });

    
    
    // default inputs actions
    obj.find('input,textarea,select').each(function () {
        var className = this.tagName == 'INPUT' ? 'in-'+this.type : 'in-'+this.tagName.toLowerCase();
        $(this).addClass('input');
        $(this).addClass(className);
    }).blur(function () {
        $(this).removeClass('focus');
    });
    if ($('input,textarea,select,div.cb_select').length) {
        obj.delegate('input,textarea,select,div.cb_select', 'hover', function() {
            $(this).toggleClass('hover');
        });
    }
    
    // no hovers for list-form
    obj.find('table.list-form input,table.list-form textarea,table.list-form select').unbind('mouseover').unbind('mouseout');
    
    // checkbox - multiselect
    obj.find('div.cb_select').addClass('input');
    
    // fix of input width for IE
    if (/msie/i.test(navigator.userAgent) && !/opera/i.test(navigator.userAgent)) {
        obj.find('.value .in-text,.value .in-password,.value .in-textarea').each(function () {
            $(this).closest('td').css('padding-right', '8px').addClass('ie-field-padding');
        });
        $('.list-form .ie-field-padding .input').each(function () {
            $(this).closest('.ie-field-padding').css('padding-right', '2px').removeClass('ie-field-padding');
            $(this).width($(this).width()-8);
        });
    }
}


/**
 * Handle default values in the inputs
 */
function initInputDefault(obj)
{
    if (!obj) {
        obj = $(document);
    }
    
    obj.find("input.default-value[title]").focus(function() {
        if ($(this).val() == $(this)[0].title) {
            $(this).val("");
            $(this).removeClass("defaultText");
        }
    }).blur(function() {
        if ($(this).val() == "") {
            $(this).val($(this)[0].title);
            $(this).addClass("defaultText");
        }
    }).blur();
}

/**
 * Set focus to the inputs with .get-focus class
 */
function initFocuses() 
{
    $('input.get-focus').focus();
}

var floatHeader = 0;

function initFloatHeader() 
{
    if(floatHeader != 0){
        $('table.list').fixedtableheader({ headerrowsize:floatHeader });
    }
}
   
function initClose()
{    
    $('[rel^=block-group-]').keyup(function (){
        var $other = $('[rel='+$(this).attr('rel')+']').not($(this));
        
        if ($(this).val()) {
            $other.attr('disabled', true).addClass('disabled'); 
        } else {
            $other.attr('disabled', false).removeClass('disabled');
        }
    });
}


/**
 * Checkbox selectionfor simple lists
 */
$('.table-switch-selector').live('click', function (){  
    $(this).closest('table').find('tbody :checkbox').filter(':enabled').attr('checked', $(this).attr('checked')).change();
});

