$('a.acc_link').live('click', function () {
	$t = $(this);
	$tr = $t.closest('tr');
	
	if($t.hasClass('clicked')) {
		$tr.find('div[id^=acc_block_]:first').hide();
        $t.removeClass('clicked');
	} else {
        $('div[id^=acc_block_]').hide();
		$('a.acc_link').removeClass('clicked');
		
		$tr.find('div[id^=acc_block_]:first').show();
        $t.addClass('clicked');
        
        $img_td = $tr.find('.orate-table-img:first');
        offset = $img_td.offset();
        $tr.find('div[id^=acc_block_]:first').css({'left' : offset.left - 7, 'top' : offset.top + $img_td.height() - 1});

        $tr.find('.oacc-rate-table-img').css('width', $('.orate-table-img:first').css('width'));
        $tr.find('.oacc-rate-table-text, .oacc-rate-table-text p').css('width', $('.orate-table-text:first').css('width'));
        $tr.find('.tacc-rate-table-img').css('width', $('.trate-table-img:first').css('width'));
        $tr.find('.tacc-rate-table-text, .tacc-rate-table-text p').css('width', $('.trate-table-text:first').css('width'));
    }
});