<?php
 
phpinfo();

?>