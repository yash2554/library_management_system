<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php if(isset($template['title'])){ echo $template['title'] ;  }?></title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
<!--    <link rel="shortcut icon" type="image/png" href="http://vcs.demo.jerasoft.net/static/favicon.png">-->

        <link type="text/css" rel="stylesheet" media="all" href="<?php echo BASE_URL ?>css/custom_style.css">
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo BASE_URL ?>css/base.css">
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo BASE_URL ?>css/main.css">
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo BASE_URL ?>css/shared.css">
        <link type="text/css" rel="stylesheet" media="print" href="<?php echo BASE_URL ?>css/print.css">
        <link type="text/css" rel="stylesheet" media="all" href="<?php echo BASE_URL ?>css/styles.css">

        <script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery-1.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery-ui-1.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery_002.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/bb-functions.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/bb-interface.js"></script>

        <script type="text/javascript">
        //<![CDATA[
        var currentTime = 1380778391;
        var L = {"loadingPanel":"Please Wait...","deleteConfirm":"Are you sure you want to delete this item?","hide-all":"hide all"};
        //]]>
        </script>

        <script type="text/javascript" src="<?php echo BASE_URL ?>js/list.js"></script>
        <script type="text/javascript" src="<?php echo BASE_URL ?>js/fixedtableheader.js"></script>

        <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL ?>css/injected.css" >
    </head>
    <body>
        <?php if(isset($_SESSION['admin']['logged_in']) && $_SESSION['admin']['logged_in']!=  0 ) { ?>

        <div id="header">
            <div id="logo">
                <a href="<?php echo BASE_URL; ?>">
                    <img src="<?php echo LOGO_URL; ?>" alt="" height="40" width="140" />
                </a>
            </div>
            <ul id="header-menu">
                <li>Signed in as : <?php echo $_SESSION['admin']['username'] ?></li>
                <li><a href="<?php echo BASE_URL; ?>admin/change-password/">Change Password</a></li><li><a href="<?php echo BASE_URL; ?>admin/logout/"><strong>Logout</strong></a></li>
            </ul>
        </div>

<div id="topmenu">
    <ul class="topmenu-left" id="topmenu-menu">
    <?php //foreach($template['menu'] as $key => $item)
        $i = 0;
        while($i<count($template['menu']))
        {
            if($template['menu'][$i]['parent']==0){
            ?>
            <li class="">
                <span>
                    <a href="<?php echo BASE_URL.$template['menu'][$i]['url'].'/'; ?>" >
                        <?php echo $template['menu'][$i]['name']; ?>
                    </a>
                </span>
    <?php   }
            if(isset($template['menu'][$i]['submenu']))
            { ?>
                <ul class="">
                    <?php
                    $j = 0;
                    while($j<count($template['menu'][$i]['submenu']))
                    { ?>
                        <li class="">
                            <a href="<?php echo BASE_URL.$template['menu'][$i]['submenu'][$j]['url'].'/'; ?>" >
                                <?php echo $template['menu'][$i]['submenu'][$j]['name']; ?>
                            </a>
                        </li>
                    <?php
                    $j++;
                    } ?>
                </ul>
    <?php
            }
            $i++;
        }
    ?>
    </ul>
    <div class="topmenu-right" ><?php echo  date('d/m/Y H:i:s'); ?></div>
    <script type="text/javascript">$('#topmenu-menu > li').bind('mouseover', jsddm_open).bind('mouseout',  jsddm_timer);</script>
</div>
<?php } ?>
