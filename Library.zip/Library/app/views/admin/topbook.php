<div id="title">
    <h1><span><?php if(isset($template['title'])) {echo $template['title'];} ?></span></h1>  
    <div class="add"><a href="<?php echo BASE_URL ?>admin/country/add/"><img src="<?php echo BASE_URL ?>images/add.png" alt="" height="16" width="16"> Add Country</a></div>
</div>  
<?php
/*
$type=2;
 require_once(MODEL_PATH."inc.class.php");
                $incObj = new Inc();
                if($type==1 || $type==2)
                {
                    return $incObj->getActiveCode(159632,8304321575,616960105060,40,"US",24902);
                }
                elseif($type==3)
                {
                    //return $incObj->getpin($cus_trans_id,$skuid,$amount,$vendor_sku_id);
                }


*/
?>
<div id="container">
<table class="list">
<thead class="table_heading">
<tr class="first_line">
    <td rowspan="2">ID</td>
    <td rowspan="2">Country Name</td>
    <td rowspan="2">Country Code</td>
    <td rowspan="2">Phone Code</td>
    <td rowspan="2">Currency Code</td>
    <td rowspan="2" colspan="3">Action</td>
</tr>
<tr></tr>
</thead>
<tbody>
    
<?php $i =1; foreach($template['countries'] as $key => $value) { ?>   
<tr class="s-active row-1">
    <td align="center"><?php echo $i; ?></td>
    <td><?php echo $value['country_name'] ?></td>
    <td><?php echo $value['country_code'] ?></td>
    <td><?php echo $value['phone_code'] ?></td>
    <td><?php echo $value['currency_code'] ?></td>
    <td align="center"><a href="<?php echo BASE_URL ?>admin/country/edit/<?php echo $value['id'] ?>/"><img src="<?php echo BASE_URL ?>images/edit.png" height="16" width="16"></a></td>    
    <td class="last"><a href="#" ><img src="<?php echo BASE_URL ?>images/delete.png" height="16" width="16" onclick="Delete(<?php echo $value['id']; ?>)"></a></td>
</tr>
<?php $i++; } ?>
</tbody>
</table>
</div>
<script type="text/javascript">
function Delete(val)
{
    var conf=confirm('Please confirm, are you sure you want delete record ?')
    if(conf==true)
    {
        $.ajax({
            type: "POST",
            data:{
                ID:val
            },
            url: "<?php echo BASE_URL ?>admin/country/delete/",
            cache: false,
            success: function(response){
                
                    $('#msg').html('Country deleted successfully');
                    location.reload();
                    
                
             }

        });
    }
   
}
    
</script>