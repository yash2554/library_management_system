<div id="title">
    <h1><span><?php if(isset($template['title'])) { echo $template['title']; } ?></span></h1> 
    <div class="add"><a href="<?php echo BASE_URL ?>admin/operators/"><img src="<?php echo BASE_URL ?>images/Back.png" alt="" height="16" width="16">&nbsp;Back To List</a></div>

</div>    
<div id="container">
  <form name="EditOperator" id="EditOperator" action="<?php echo BASE_URL ?>admin/operator/edit/<?php if(isset($template['id'])) { echo $template['id']; } ?>/" class="forms" method="post">
    <div class="field_row">
        <label class="label">Operator Name<span class="star">*</span></label>
        <div class="field"><input type="text" name="o_name" id="o_name" class="input in-text" value="<?php if(isset($template['o_name']))  {echo $template['o_name']; } ?>"></div>
    </div>   
    <div class="field_row">
        <label class="label">Country<span class="star">*</span></label>
        <select name="c_code">
                <option value="" disabled>Select</option>
                <?php foreach($template['country_list'] as $key =>$value) { 
                     if(isset($template['country']) && ($template['country'] == $value['country_code']))
                        {
                            $selected = 'Selected="true"';
                        }
                        else
                        {
                              $selected = '';

                        }
                 ?>
                <option <?php echo $selected;  ?> value="<?php echo $value['country_code'] ?>"><?php echo $value['country_name'] ?></option>
                <?php } ?>
        </select>   
    </div>
    
    <div class="submitbtn">
        <input type="submit" name="edit_operator" id="edit_country" value="Update" onClick="formvaliadtion(event);" />
    </div>
  </form>
</div>
<script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.validate.min.js"></script>
<script>
function formvaliadtion(event){
  
$("#EditOperator").validate({
      errorElement: "div",
      errorClass: "alert alert-error",
      errorPlacement: function(error, element) {
      error.appendTo( element.parent("div"));
      },
      rules:{
          
          o_name:"required",
          c_code:"required"
               
          
      },
      messages:{
          o_name : "Please Enter an Operator Name",
          c_code : "Please Select Country Code"
         
        }
    });
   }  
    
</script>