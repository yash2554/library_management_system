<div id="title">
    <h1><span><?php if(isset($template['title'])){ echo $template['title'];} ?></span></h1>
    <div class="add"><a href="<?php echo BASE_URL ?>admin/customers/"><img src="<?php echo BASE_URL ?>images/Back.png" alt="" height="16" width="16">&nbsp;Back To List</a></div>
</div>
<div id="container">
    <form name="Editassignsku" id="Editassignsku" action="<?php echo BASE_URL ?>admin/assignsku/edit/<?php if(isset($template['id'])){ echo $template['id']; } ?>" class="forms" method="post">
    <div class="field_row">
        <label class="label">Customer Name<span class="star">*</span></label>
        <div class="field">
            <select name="c_name" id="c_name">
                 ?>
                 <option value="<?php echo $template['id']; ?>" ><?php echo $template['name']; ?></option>
            </select>
        </div>
    </div>
    <div class="field_row">
      <label class="label">Use Default discount</label>
      <div class="field"><input type="text" name="d_discount" id="d_discount" class="input in-text" style="width:125px">
          <a id="selectall" onclick="copy_discount()"><img src="<?php echo BASE_URL ?>images/Copy.png" width="32" height="28" alt="copy" title="copy"></a>
      </div>
     </div>
     <div class="field_row">
        <label class="label" style="width:30%">Sku Code<span class="star">*</span></label>
        <label class="label" style="width:20%">Discount</label>
        <label class="label" style="width:20%">Deduction</label>
        <label class="label" style="width:30%">New Discount<span class="star">*</span></label>

             <?php
                $i=0;
                foreach($template['csku_data'] as $key => $value)
                { ?>
                <div class="field_row">
                    <label class="label" style="width:20px;">
                        <input type="checkbox" name="skucode_<?php echo $value['sku_id']; ?>" class="code assign" <?php if(isset($template['sku_code'])){if(in_array($value['sku_id'], $template['sku_code'])){ echo ' checked="true" '; }} ?>  value="<?php echo $value['sku_id']; ?>" />
                    </label>
                    <label class="label" style="width:25%" id="lable_<?php echo $value['sku_id']; ?>" ><?php echo $value['sku_id']; ?></label>
                    <label class="label" style="width:15%;"><?php echo $value['discount']; ?></label>
                    <label class="label" style="width:15%;"><?php echo $value['deduction']; ?></label>
                    <div class="field" style="width:25%">
                        <input type="text" id="discount_<?php echo $value['sku_id']; ?>" name="discount_<?php echo $value['sku_id']; ?>" id="discount" class="input in-text discount" style="width:100px;"
                                            value="<?php if(isset($template['sku_code'])){if(in_array($value['sku_id'], $template['sku_code'])){ $key=(array_search($value['sku_id'], $template['sku_code'])); {
                                                echo $template['discount'][$key]; }}} ?>" />
                    </div>
                </div>

            <?php
                $i++;
                }
            ?>
    </div>

</form>
</div>
<script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.validate.min.js"></script>
<script type="text/javascript" >
    function copy_discount()
    {
        $(".discount").val($("#d_discount").val());
    }

    $('.assign').click(function(event)
    {
        var name = $(this).attr("name");
        var skucode = name.split("_");

        var discount = $("#discount_"+skucode[1]).val();
        var checkbox  = this;
        if(this.checked==true)
        {
            this.checked = false; // reset first


            if(discount=="")
            {
                alert("Please enter a discount");
                $("#discount_"+skucode[1]).css('background-color',"#F2DEDE");
                $("#lable_"+skucode[1]).css('color',"#B94A48");
            }
            else
            {
                $("#discount_"+skucode[1]).css('background-color',"#FFFFFF");
                $("#lable_"+skucode[1]).css('color',"#5E6771");
                $.ajax({
                    type: "POST",
                    data:{
                        customer: $("#c_name").val(),
                        sku : skucode[1],
                        discount : discount

                    },
                    url: "<?php echo BASE_URL ?>admin/assignSku/",
                    cache: false,
                    success: function(response){
                        checkbox.checked=true

                      }
                });
            }
        }
        else
        {

            $.ajax({
                    type: "POST",
                    data:{
                        customer: $("#c_name").val(),
                        sku : skucode[1]
                    },
                    url: "<?php echo BASE_URL ?>admin/unassignSku/",
                    cache: false,
                    success: function(response){
                        checkbox.checked=false
                         $("#discount_"+skucode[1]).val("");
                      }
                });
        }



        event.preventDefault();
        // event.stopPropagation() like in Zoltan's answer would also spare some
        // handler execution time, but is no more needed here

        // then do the heavy processing:
    });

</script>