<form  id ="login"  action="<?php echo BASE_URL ?>admin/change-password/" method="post">

        <legend class="heading">Change Password</legend>
        <div id="error_msg">
        </div>
        <?php
            if(isset($template['error_msg']))
            {
                echo $template['error_msg'];
            }
        ?>
        <label>Username:admin</label>
        <label>Current Password</label>
        	<input id="cur_password" type="password" name="current_password" class="input in-password"/>
    	<label>New Password</label>
        	<input id="new_password" type="password" name="new_password" class="input in-password"/>
        <label>Confirm New Password</label>
        	<input id="conf_password" type="password" name="conf_password" class="input in-password"/>
        <button class="input in-submit" type="submit" onclick="formvalidation(event)" >Update</button>
</form>
<script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.validate.min.js"></script>
<script type="text/javascript">
function formvalidation(event){

$("#login").validate({
      errorElement: "div",
      errorClass: "alert alert-error",
      errorPlacement: function(error, element) {
      error.appendTo( element.parent().find("#error_msg"));
      },
      rules:{
           current_pass: {required:true},
           new_password: {required:true},
           conf_password: {required:true,equalTo: "#new_password"}
      },
      messages:{
            current_pass: {required:"Please Enter Current Password"},
            new_password: {required:"Please Enter New Password"},
            conf_password:{required:"Please Enter Confirm Password",equalTo:"Sorry th"}
       }
    });
   }

</script>