<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL . "css/jquery-ui.css"; ?>" ></link>
<script type="text/javascript" href="<?php echo BASE_URL . "js/calender.js"; ?>" ></script>
 <script>
  $( function() {
    $( "#date" ).datepicker();
  } );
  </script>
<div id="title">
    <h1><span><?php echo $template['title']; ?></span></h1>  
    <div class="add"><a href="<?php echo BASE_URL ?>admin/book/"><img src="<?php echo BASE_URL ?>images/Back.png" alt="" height="16" width="16">&nbsp;Back To List</a></div>

</div>    
<div id="container">
<form name="AddCountry" id="AddCountry" action="<?php echo BASE_URL ?>admin/book/add/" class="forms" method="post">
    <div class="field_row">
        <label class="label">Book Title<span class="star">*</span></label>
        <div class="field"><input type="text" name="book_title" id="c_name" class="input in-text"></div>
    </div>   
    <div class="field_row">
        <label class="label">Book Author<span class="star">*</span></label>
        <div class="field"><input type="text" name="b_auhtor" id="c_code" class="input in-text"></div>
    </div>
    <div class="field_row">
        <label class="label">ISBN<span class="star">*</span></label>
        <div class="field"><input type="text" name="ISBN" id="p_code" class="input in-text"></div>
    </div>
    <div class="field_row">
        <label class="label">Publisher<span class="star">*</span></label>
        <div class="field"><input type="text" name="pub_name" id="cu_code" class="input in-text"></div>
    </div>
      <div class="field_row">
        <label class="label">Publisher Date<span class="star">*</span></label>
        <div class="field"><input type="text" name="pub_date" id="date" class="input in-text"></div>
    </div>
    <div class="submitbtn">
        <input type="submit" name="add_country" id="add_country" value="Add" onClick="formvaliadtion(event)" />
    </div>
</form>
</div>
 <script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.validate.min.js"></script>
<script>
function formvaliadtion(event){
  
$("#AddCountry").validate({
      errorElement: "div",
      errorClass: "alert alert-error",
      errorPlacement: function(error, element) {
      error.appendTo( element.parent("div"));
      },
      rules:{
          c_name:"required",
          c_code:"required",
          p_code:"required",
          cu_code:"required"
          
          
      },
      messages:{
          c_name : "Please Enter a Country Name",
          c_code:"Please Enter a Country Code",
          p_code:"Please Enter a Phone Code" ,
          cu_code:"Please Enter a Currency Code"
        }
    });
   }  
    
</script>