<div id="title">
    <h1><span><?php if(isset($template['title'])) {echo $template['title'];} ?></span></h1>
		<?php if($_SESSION['admin']['username']=="admin"){?>
	    <div class="add"><a href="<?php echo BASE_URL ?>admin/customer/add/"><img src="<?php echo BASE_URL ?>images/add.png" alt="" height="16" width="16"> Add Customer</a></div>
	</div>
		<?php }?>

<div id="container">
<table class="list">
<thead class="table_heading">
<tr class="first_line">
    <td rowspan="2">ID</td>
    <td rowspan="2">Company Name</td>
    <td rowspan="2">First Name</td>
    <td rowspan="2">last Name</td>
    <td rowspan="2">User Name</td>
    <td rowspan="2">Address</td>
    <td rowspan="2">City</td>
    <td rowspan="2">State</td>
    <td rowspan="2">Zip</td>
    <td rowspan="2">E-mail</td>
    <td rowspan="2">Credit Limit </td>
    <td rowspan="2">Daily Limit</td>
    <td rowspan="2">Credit Used</td>
    <td rowspan="2">Credit Available</td>
    <td rowspan="2">Status</td>
    <td rowspan="2" colspan="3">Action</td>
</tr>
<tr></tr>
</thead>
<tbody>
<?php foreach($template['customer_data'] as $key => $value) { ?>
<tr class="s-active row-1">
    <td align="center"><?php echo $value['id'] ?></td>
    <td><?php echo $value['company_name']; ?></td>
    <td><?php echo $value['fname']; ?></td>
    <td><?php echo $value['lname']; ?></td>
    <td><?php echo $value['username']; ?></td>
    <td><?php echo $value['address']; ?></td>
    <td><?php echo $value['city']; ?></td>
    <td><?php echo $value['state']; ?></td>
    <td><?php echo $value['zip']; ?></td>
    <td><?php echo $value['email']; ?></td>
    <td><?php echo $value['credit_limit']; ?></td>
    <td><?php echo $value['daily_limit']; ?></td>
    <td><?php echo $value['credit_used']; ?></td>
    <td><?php echo $value['credit_limit'] - $value['credit_used']; ?></td>
    <?php 
      
       if($value['status'] == 1)
       {
           $status = 'Active';     
       }
       else{
           
           $status = 'Inactive'; 
       }
    ?>
    <td><?php echo $status; ?></td>
    <td align="center"><a href="<?php echo BASE_URL ?>admin/customer/edit/<?php echo $value['id'] ?>/"><img src="<?php echo BASE_URL ?>images/edit.png" height="16" width="16" title="Edit"></a></td>
    <td align="center"><a href="<?php echo BASE_URL ?>admin/assignsku/edit/<?php echo $value['id'] ?>/"><img src="<?php echo BASE_URL ?>images/Assign.png" height="20" width="20" title="Assign Sku"></a></td>
    <td class="last"><a href="#" ><img src="<?php echo BASE_URL ?>images/delete.png" height="16" width="16" title="Delete" onclick="Delete(<?php echo $value['id']; ?>)"></a></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
<script type="text/javascript">
function Delete(val)
{
    var conf=confirm('Please confirm, are you sure you want delete record ?')
    if(conf==true)
    {
        $.ajax({
            type: "POST",
            data:{
                ID:val
            },
            url: "<?php echo BASE_URL ?>admin/customer/delete/",
            cache: false,
            success: function(response){

                    $('#msg').html('Customer deleted successfully');
                    location.reload();


             }

        });
    }

}

</script>