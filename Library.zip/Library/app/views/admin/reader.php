<div id="title">
    <h1><span><?php if(isset($template['title'])) {echo $template['title'];} ?></span></h1>  
    <div class="add"><a href="<?php echo BASE_URL ?>admin/addreader/"><img src="<?php echo BASE_URL ?>images/add.png" alt="" height="16" width="16"> Add Reader</a></div>
</div>  
<div id="container">
    <div id="msg"></div>
<table class="list">
<thead class="table_heading">
<tr class="first_line">
    <td rowspan="2">ID</td>
    <td rowspan="2">First Name</td>
    <td rowspan="2">Last Name</td>
    <td rowspan="2">Address</td>
    <td rowspan="2">City</td>
    <td rowspan="2">State</td>
    <td rowspan="2">Zipcode</td>
    <td rowspan="2">Contact</td>
    <td rowspan="2">Email</td>
    <td rowspan="2" colspan="3">Action</td>
</tr>
<tr></tr>
</thead>
<tbody>
<?php foreach($template['reader'] as $key => $value) { ?>   
<tr class="s-active row-1">
    <td align="center"><?php echo $value['id'] ?></td>
    <td><?php echo $value['name'] ?></td>
    <td><?php echo $commonFunction->country_name($value['country']); ?></td>
    <td align="center"><a href="<?php echo BASE_URL ?>admin/reader/edit/<?php echo $value['id'] ?>/"><img src="<?php echo BASE_URL ?>images/edit.png" height="16" width="16"></a></td>    
    <td class="last"><a href="#" ><img src="<?php echo BASE_URL ?>images/delete.png" height="16" width="16" onclick="Delete(<?php echo $value['id']; ?>)"></a></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
<script type="text/javascript">
function Delete(val)
{
    var conf=confirm('Please confirm, are you sure you want delete record ?')
    if(conf==true)
    {
        $.ajax({
            type: "POST",
            data:{
                ID:val
            },
            url: "<?php echo BASE_URL ?>admin/operator/delete/",
            cache: false,
            success: function(response){
               if(response == 0)
               {                   
                    $('#msg').html('Operator deleted successfully');
                    location.reload();
               }
               else{
                   $('#msg').html('Operator is Already in Used');
               }
                
             }

        });
    }
   
}
    
</script>