<script type="text/javascript" src="<?php echo BASE_URL ?>js/user_add.js"></script>
<div id="title">
    <h1><span><?php if (isset($template['title'])) {
    echo $template['title'];
} ?></span></h1>  
    <div class="add"><a href="<?php echo BASE_URL ?>admin/createuser/"><img src="<?php echo BASE_URL ?>images/Back.png" alt="" height="16" width="16">&nbsp;Back To List</a></div>

</div>    
<div id="container">
    <form name="AddCountry" id="AddCountry" action="<?php echo BASE_URL ?>admin/reader/add/" class="forms" method="post">
        <div class="field_row">
            <label class="label">Card No>:<span class="star">*</span></label>
             <div class="field"><input type="text" name="cardno" id="username" class="input in-text"></div>
        </div>  

        <div class="field_row">
            <label class="label">Firstname<span class="star">*</span></label>
            <div class="field"><input type="text" name="username" id="username" class="input in-text"></div>
        </div>   
        <div class="field_row">
            <label class="label">Lastname<span class="star">*</span></label>
            <div class="field"><input type="password" name="password" id="password" class="input in-text"></div>
        </div>

    
            <div class="field_row">
                <label class="label">Address 1:<span class="star"></span></label>
                <div class="field"><input type="text" name="street" id="customer" class="input in-text"></div>
            </div>
      
            <div class="field_row">
                <label class="label">City<span class="star"></span></label>
                <div class="field"><input type="text" name="city" id="customer" class="input in-text"></div>
            </div>
        <div class="field_row">
                <label class="label">State<span class="star"></span></label>
                <div class="field"><input type="text" name="city" id="customer" class="input in-text"></div>
            </div>
      
        <!--       <div class="field_row">-->
             <!--   <label class="label">Transaction Detail<span class="star"></span></label>-->
        <div class="field"><input type="hidden" name="transaction_detail" id="customer" class="input in-text"></div>
        <!--    </div>
               <div class="field_row">-->
        <!--        <label class="label">Export LCR<span class="star"></span></label>-->
        <div class="field"><input type="hidden" name="lcr" id="customer" class="input in-text"></div>
        <!--    </div>
               <div class="field_row">-->
        <!--        <label class="label">Detail Report<span class="star"></span></label>-->
        <div class="field"><input type="hidden" name="report" id="customer" class="input in-text"></div>
        <!--    </div>-->
        <div class="form_class">

            <div class="field_row">
                <label class="label">Summary Report<span class="star"></span></label>
                <div class="field"><input type="checkbox" name="summary" id="customer" class="input in-text"></div>
            </div>
        </div>
        <div class="form_class">

            <div class="field_row">
                <label class="label">Create User<span class="star"></span></label>
                <div class="field"><input type="checkbox" name="create_user" id="customer" class="input in-text"></div>
            </div>
        </div>


        <div class="submitbtn">
            <input type="submit" name="add_user" id="add_user" value="Add" onClick="formvaliadtion(event)" />
        </div>
    </form>
</div>
<script type="text/javascript" src="<?php echo BASE_URL ?>js/jquery.validate.min.js"></script>
<script>
            function formvaliadtion(event) {

                $("#AddCountry").validate({
                    errorElement: "div",
                    errorClass: "alert alert-error",
                    errorPlacement: function (error, element) {
                        error.appendTo(element.parent("div"));
                    },
                    rules: {
                        username: "required",
                        password: "required",
                    },
                    messages: {
                        username: "Please Enter a User Name",
                        password: "Please Enter a Password",
                    }
                });
            }

</script>