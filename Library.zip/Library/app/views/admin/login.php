<form  id ="login"  action="<?php echo BASE_URL?>admin/login/" method="post">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
    <legend class="heading">Login</legend>
    <?php
    if (isset($template['error_msg'])) {
        echo $template['error_msg'];
    }
    ?>
    <select id="controller" name="controller" >
           <option value="reader" id="reader" >Reader</option>
        <option value="admin" id="admin" >Library Staff</option>
     
    </select>
    <div id="admin_panel">
        <label>Username</label>
        <input id="auth-login" name="username" type="text" class="input in-text">
        <label>Password</label>
        <input id="auth-password" type="password" name="password" class="input in-password"/>
    </div>
    <div id="reader_panel">
        <label>Card No.</label>
        <input id="auth-login" name="username_reader" type="text" class="input in-text">
<!--        <label>Password</label>
        <input id="auth-password" type="password" name="password" class="input in-password"/>-->
    </div>

    <button class="input in-submit" type="submit" >Login</button>
</form>
<script type="text/javascript">
  
    
    window.onload = function () {
    $('#admin_panel').hide();
//    $('#reader_panel').hide();
    };
   
 
 document.getElementById('controller').addEventListener('change', function () {
    var style = this.value;
  
    if(style ==='reader'){
         $("#reader_panel").show(1000);
         $('#admin_panel').hide();
    }
    else if(style ==='admin'){
           $("#admin_panel").show(1000);
         $('#reader_panel').hide();
    }
//    document.getElementById('hidden_div').style.display = style;
});


</script>