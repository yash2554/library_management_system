<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL."css/jquery-ui.css";?>" ></link>
<div id="title">
    <h1><span><?php if(isset($template['title'])) {echo $template['title'];} ?></span></h1>
    <!--<div class="add"><a href="<?php echo BASE_URL ?>admin/downloadpin/"><img src="<?php echo BASE_URL ?>images/import-icon.png" alt="" height="16" width="16"> Export To CSV</a><a href="<?php echo BASE_URL ?>admin/uploadpin/"><img src="<?php echo BASE_URL ?>images/export.png" alt="" height="16" width="16">Upload CSV</a></div>-->
</div>






<div id="container">
    <form class="forms" action="" method="POST">
	<div class="field_row">
            <label class="label">Book Title</label>
            <div class="field"><input type="text" name="pin" class="input in-text"></div>
        </div>


    
        <div class="field_row">
            <button name="export" value="0" type="submit">Show Status</button>
            <!-- <button name="export" value="1" type="submit">Export Report</button> -->
        </div>
    </form>



<?php if(!empty($_POST)) { ?>
<form method="POST">
    <table class="list">
    <thead class="table_heading">
    <tr class="first_line">
        <td rowspan="2">ISBN</td>
        <td rowspan="2">Book Title</td>
        <td rowspan="2">Book Author</td>
        <td rowspan="2">Book Publisher</td>
        <td rowspan="2">Book Publisher Date</td>
        <td rowspan="2">Action</td>

    </tr>
    <tr></tr>
    </thead>
    <tbody>
    <?php foreach($template['book'] as $key => $value) { ?>
    <tr class="s-active row-1">
        <td align="center"><?php echo $value['id'] ?></td>
        <td><?php echo $value['sku_id']; ?></td>
        <td><?php echo $value['pin_code']; ?></td>
        <td><?php echo $value['pin_instructions']; ?></td>
        <td><?php if($value['is_sold'] == 1) { echo 'Yes';} else{echo 'No'; } ?></td>
        <td class="last"><a href="#" ><img src="<?php echo BASE_URL ?>images/delete.png" height="16" width="16" onclick="deletePin(<?php echo $value['id']; ?>)"></a></td>
    </tr>
    <?php } ?>
    </tbody>
    </table>
    </form>

<?php } ?>
</div>
<script type="text/javascript">
function deletePin(val)
{
    var conf=confirm('Please confirm, are you sure you want delete record ?')
    if(conf==true)
    {
        $.ajax({
            type: "POST",
            data:{
                pin_id:val
            },
            url: "<?php echo BASE_URL ?>admin/deletepin/",
            cache: false,
            success: function(response){
                $('#msg').html('Pin deleted successfully');
                location.reload();
            }
        });
    }

}
    $(document).ready(function()
    {
        $("input[name='from']").datepicker({changeMonth:true,changeYear:true});
        $("input[name='to']").datepicker({changeMonth:true,changeYear:true});
    });
</script>