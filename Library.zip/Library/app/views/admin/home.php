
<div id="title">
    <h1><span><?php if(isset($template['title'])) {echo $template['title'];} ?></span></h1>
    <!-- <div class="add"><a href="<?php echo BASE_URL ?>admin/vendor/add/"><img src="<?php echo BASE_URL ?>images/add.png" alt="" height="16" width="16"> Add Vendor</a></div> -->
</div>

