<?php

class AdminController {

    var $view = 'default';
    var $has_access = array();
    var $render = TRUE;
    var $output = array();

    public function _before() {
        require_once(MODEL_PATH . "menu.class.php");
        $menuObj = new Menu();
        $menulist = $menuObj->getMenu();
        $this->output['menu'] = $menulist;
        return $this->output;

        if (!isset($_SESSION['admin']['logged_in']) || !isset($_SESSION['reader']['logged_in'])) {
            $_SESSION['controller']['logged_in'] = 0;
            }
    }

    public function login() {
        global $commonFunction;
//        if(isset($_SESSION['controller']['logged_in']) && $_SESSION['controller']['logged_in']==0){
        if (isset($_SESSION['admin']['logged_in']) && $_SESSION['admin']['logged_in'] == 0) {
            if (!empty($_POST)) {
                require_once(MODEL_PATH . "user.class.php");
                $userObj = new User();
              
                $user = $userObj->login_admin($_POST['username'], $_POST['password']);
                if (!empty($user)) {
                    $_SESSION['admin']['logged_in'] = $user[0]['idadmin'];
                    $_SESSION['admin']['username'] = $user[0]['username'];

                    $commonFunction->Redirect(BASE_URL . 'admin/home/');
                } else {
                    $_SESSION['admin']['logged_in'] = 0;
                    $this->output['error_msg'] = "Apologies, but Your Majesty's name and key are not the right combination!";
                }
            }
        } else {
            $commonFunction->Redirect(BASE_URL . 'admin/home/');
        }
    
//    else{
//        
//    }
        $this->output['title'] = "Login";
        return $this->output;
    }
    public function home() {
            global $commonFunction;
           $this->output['title'] = "Welcome";
        return $this->output;
    }
    public function logout() {
        global $commonFunction;
        unset($_SESSION);
        session_destroy();
        $commonFunction->Redirect(BASE_URL . 'admin/login/');
        $this->RENDER = FALSE;
    }

    public function index() {
        require_once(MODEL_PATH . "menu.class.php");
        $menuObj = new Menu();
        $menulist = $menuObj->getMenu();
        $this->output['menu'] = $menulist;
        return $this->output;
    }

    ############################## Country Start ###########################################################
 public function searchbook() {
        require_once(MODEL_PATH . "book.class.php");
        $bookObj = new Book();
        $title = 'Search Book';
        $this->output['title'] = $title;
        if (!empty($_POST)) {
            $this->output['book'] = $SkuObj->getbook_list_search($_POST);
        }
        return $this->output;
    }
    public function addbook() {

        global $commonFunction;
        require_once(MODEL_PATH . "book.class.php");
        $bookObj = new Book();
        $title = "Add Book";

        if (!empty($_POST)) {
          //  $countryname = $commonFunction->clean($_POST['c_name']);
            $book_title = $_POST['book_title'];
            $b_author = $_POST['b_auhtor'];
            $ISBN = $_POST['ISBN'];
            $currencycode = $_POST['cu_code'];
            $countryObj->add_country($countryname, $countrycode, $phonecode, $currencycode);
            $commonFunction->Redirect(BASE_URL . 'admin/addbook/');
        }
        $this->output['title'] = $title;
        return $this->output;
    }

    public function book_edit($paramArr) {

        global $commonFunction;
        require_once(MODEL_PATH . "book.class.php");
        $bookObj = new Book();
        $title = "Edit Book";
        $id = $paramArr[0];

        if (!empty($_POST)) {

            $countryname = $commonFunction->clean($_POST['c_name']);
            $countrycode = $_POST['c_code'];
            $phonecode = $_POST['p_code'];
            $currencycode = $_POST['cu_code'];
            $countryObj->update_country($id, $countryname, $countrycode, $phonecode, $currencycode);
            $commonFunction->Redirect(BASE_URL . 'admin/book/');
        }
        $book_data = $countryObj->getBook($id);
        $country_name = $country_data[0]['country_name'];
        $country_code = $country_data[0]['country_code'];
        $phone_code = $country_data[0]['phone_code'];
        $currency_code = $country_data[0]['currency_code'];
        $this->output['country_name'] = $country_name;
        $this->output['country_code'] = $country_code;
        $this->output['phone_code'] = $phone_code;
        $this->output['currency_code'] = $currency_code;
        $this->output['id'] = $id;
        $this->output['title'] = $title;
        return $this->output;
    }

    public function book() {
        require_once(MODEL_PATH . "book.class.php");
        $bookObj = new Book();
        $title = "Books";
        $book_data = $bookObj->getBookList();
        $this->output['books'] = $book_data;
        $this->output['title'] = $title;
        return $this->output;
    }

    public function book_delete() {
        require_once(MODEL_PATH . "book.class.php");
        $bookObj = new Book();
        if (!empty($_POST)) {
            $id = $_POST['ID'];
            $bookObj->book_delete($id);
        }
        $this->RENDER = FALSE;
    }

    ################################# Operator Start ############################################

    public function addreader() {
        global $commonFunction;
        require_once(MODEL_PATH . "reader.class.php");
        $ReaderObj = new Reader();

//        require_once(MODEL_PATH . "country.class.php");
//        $countryObj = new Country();

        $title = "Add Reader";
        $this->output['title'] = $title;

      if (!empty($_POST)) {
          //  $countryname = $commonFunction->clean($_POST['c_name']);
            $countrycode = $_POST['c_code'];
            $phonecode = $_POST['p_code'];
            $currencycode = $_POST['cu_code'];
            $countryObj->add_country($countryname, $countrycode, $phonecode, $currencycode);
            $commonFunction->Redirect(BASE_URL . 'admin/addbook/');
        }
       
        return $this->output;
    }

    public function reader_edit($paramArr) {
        global $commonFunction;
        require_once(MODEL_PATH . "Reader.class.php");
        $ReaderObj = new Reader();

     

        $id = $paramArr[0];
        $title = "Edit Reader";

    

        if (!empty($_POST)) {
            $operatorname = $commonFunction->clean($_POST['o_name']);
            $country = $_POST['c_code'];
            $modifyby = $_SESSION['admin']['logged_in'];
            $modifyon = date('Y-m-d H:i:s');
            $OperatorObj->update_operator($id, $operatorname, $country, $modifyby, $modifyon);
            $commonFunction->Redirect(BASE_URL . 'admin/operators/');
        }
        $operator_data = $OperatorObj->getOperator($id);

        $this->output['title'] = "Edit Operator";
        $this->output['o_name'] = $operator_data[0]['name'];
        $this->output['country'] = $operator_data[0]['country'];
        $this->output['id'] = $operator_data[0]['id'];
        return $this->output;
    }

    public function reader() {

        require_once(MODEL_PATH . "Reader.class.php");
        $ReaderObj = new Reader();
        $title = 'Readers';
        $reader_data = $ReaderObj->getReaderList();
        $this->output['reader'] = $reader_data;
        $this->output['title'] = $title;
        return $this->output;
    }

    public function reader_delete() {

        require_once(MODEL_PATH . "reader.class.php");
   $ReaderObj = new Reader();
        if (!empty($_POST)) {
            $id = $_POST['idreader'];
            $id = $ReaderObj->reader_delete($id);
            echo $id;
        }
        $this->RENDER = FALSE;
        exit();
    }
####### Branch########
 public function branch() {
        require_once(MODEL_PATH . "branch.class.php");
        $branchObj = new Branch();
        $title = 'Search Branch';
        $this->output['title'] = $title;
        if (!empty($_POST)) {
            $this->output['book'] = $SkuObj->getbook_list_search($_POST);
        }
        return $this->output;
    }
    
    
    ################################# Top 10 Start ############################################
public function topbook(){
      require_once(MODEL_PATH . "book.class.php");
       $bookObj = new Book();
       
       
        $title = 'Top 10 Books';
        $this->output['title'] = $title;
}
public function topborrow(){
    require_once(MODEL_PATH . "borrow.class.php");
       $borrowObj = new Borrow();
       
       
        $title = 'Top 10 Borrowers';
        $this->output['title'] = $title;
}    

########Fine Start######

public function fine(){
    require_once(MODEL_PATH . "fine.class.php");
       $finebj = new Fine();
       
       
        $title = 'Top 10 Fine';
        $this->output['title'] = $title;
}

