<?php
class AjaxController
{
    var $view='ajax';

    public function _before()
    {
        $this->view = 'ajax';

    }

    public function getOperators()
    {
     require_once(MODEL_PATH."operator.class.php");
     $operatorObj = new Operator();

         //print_r($_POST);

        if(!empty($_POST)){
        $search_result =  $operatorObj->getSearchOperator($_POST['operator_name']);
        echo json_encode($search_result);
        }
        exit;

      // $this->RENDER = FALSE;
    }
    public function getusedcredit()
    {
        require_once(MODEL_PATH."customer.class.php");
        $customerObj = new Customer();
        if(!empty($_POST) && $_POST['ID']!=0 ){
        $id=$_POST['ID'];
        $custome_data=$customerObj->getCustomer($id);
        $credit_used=$custome_data[0]['credit_used'];
        echo $credit_used;
        }
        exit;
    }

    public function skucodecheck()
    {
        require_once(MODEL_PATH."sku.class.php");
        $SkuObj = new Sku();
        if(!empty($_POST)){
            if(isset($_POST['ID'])){
            $id=$_POST['ID'];
            }
            else{
             $id='';   
            }
            $skucode=$_POST['s_code'];
            if(isset($_POST['action'])){
             $action=$_POST['action'];
            }
            else{
             $action='';   
            }
            $sku_data=$SkuObj->getUniqueSku($skucode,$id,$action);
          
            echo $sku_data;
        }

    }

}
?>