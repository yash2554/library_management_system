<?php
class Book extends DBAccess
{
    public function add_book($c_name,$c_code,$p_code,$cu_code)
    {
        $query = "INSERT INTO ".TBL_BOOK."
               (country_name,
                country_code,
                phone_code,
                currency_code,
                status)
                VALUES
               ('".$c_name."',
                '".$c_code."',
                '".$p_code."',
                '".$cu_code."',
                '1')";
        $this->ExecuteQuery($query);
    }

    public function getCountry($id)
    {
        $query = "SELECT * FROM ".TBL_COUNTRIES." WHERE id='".$id."' AND status=1";
        $country = $this->SimpleQuery($query);
        return $country;
    }

    public function update_country($id,$c_name,$c_code,$p_code,$cu_code)
    {
        $query = "UPDATE ".TBL_COUNTRIES."
                      SET
                      country_name='".$c_name."',
                      country_code='".$c_code."',
                      phone_code='".$p_code."',
                      currency_code='".$cu_code."'
                      WHERE id=".$id." ";
        $country = $this->ExecuteQuery($query);
        return $country;
    }

    public function getCountryList()
    {
        $query = "SELECT * FROM ".TBL_COUNTRIES." WHERE status=1 ORDER BY country_name ASC";
        $country = $this->SimpleQuery($query);
        return $country;
    }

   public function country_delete($id)
   {
        $query = "UPDATE ".TBL_COUNTRIES."
                      SET
                      status='0'
                      WHERE id=".$id." ";
        $this->ExecuteQuery($query);
   }

   // For Operator getUniqueCountry
   public function getUniqueCountry()
   {
        $query = "SELECT distinct(country_code),country_name FROM ".TBL_COUNTRIES." WHERE status=1 ORDER BY country_name ASC";
        $country = $this->SimpleQuery($query);
        return $country;

   }
    //For Vendor SKU getUniquecurrency
    public function getUniquecurrency()
    {
        $query = "SELECT distinct(currency_code) FROM ".TBL_COUNTRIES." WHERE status=1";
        $country = $this->SimpleQuery($query);
        return $country;
    }
}