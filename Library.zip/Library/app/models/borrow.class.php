<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Borrow extends DBAccess {

    public function Credit_Report($request) {
        if ($request['customer'] == 0) {
            $query = "SELECT c.amount,c.comment, c.datetime,cust.company_name from " . TBL_CUSTOMER_CREDIT_LOG." as c INNER JOIN ".TBL_CUSTOMERS." as cust on c.customer_id=cust.id ORDER BY c.datetime DESC";
        } else {
            $query = "SELECT c.amount,c.comment, c.datetime,cust.company_name FROM " . TBL_CUSTOMER_CREDIT_LOG . " as c INNER JOIN ".TBL_CUSTOMERS." as cust on c.customer_id=cust.id where customer_id=" . $request['customer']." ORDER BY c.datetime DESC";
        }
        
        $credit_log = $this->SimpleQuery($query);
        
        return $credit_log;
      }

}
