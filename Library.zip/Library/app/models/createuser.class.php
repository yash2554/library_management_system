<?php

class Createuser extends DBAccess
{
    public function authenticate($username)
    {
        $query = "SELECT * FROM ".TBL_USER." WHERE username='".$username."' AND status=1";
        $user = $this->SimpleQuery($query);
        return $user;
    }

    public function insertUser($username,$password,$customer)
    {
        $query = "INSERT INTO ".TBL_USER."
                                    (
                                        username,
                                        password,
                                        status,
                                        customer_id
                                    )
                                    VALUES
                                    (
                                        '".$username."',
                                        '".md5($password)."',
                                        1,
                                        ".$customer."
                                        )";
        $user_id = $this->ExecuteQuery($query);
	return $user_id;
    }

    public function updateUser($username,$password,$status,$id)
    {
        if($password==""){
              $query = "UPDATE ".TBL_USER." SET
                                        username = '".$username."',
                                        status = ".$status." 
                                         WHERE
                                        id='".$id."' ";
      
        }
        else{
        $query = "UPDATE ".TBL_USER." SET
                                        username = '".$username."',
                                        password = '".md5($password)."',
                                        status = ".$status." 
                                         WHERE
                                        id='".$id."' ";
        }
        $this->ExecuteQuery($query);
    }

    public function add_access($user_id,$add_customer_sku,$add_vendor_sku,$cust_selection,$ven_selection,$pin_sel)
    {
        $query = "INSERT INTO ".TBL_USER_LEVEL."
                                    (   user_id,
                                        Add_Customer_SKU,
                                        add_vendor_sku,
                                        ven_selection,
                                        cust_selection,
                                        pin
                                       )
                                    VALUES
                                    (
                                        '".$user_id."',
                                        '".$add_customer_sku."',
                                        '".$add_vendor_sku."',
                                            '".$ven_selection."',
                                                '".$cust_selection."',
                                                    '".$pin_sel."'
                                     )";
        
        $id = $this->ExecuteQuery($query);
       
        return $id;

    }
     public function update_access($user_id,$add_customer_sku,$add_vendor_sku,$ven_selection,$cust_selection,$pin_sel)
    {
        $query = "UPDATE ".TBL_USER_LEVEL." SET 
                                        Add_Customer_SKU='".$add_customer_sku."', 
                                        add_vendor_sku='".$add_vendor_sku."',
                                        ven_selection='".$ven_selection."',
                                        cust_selection='".$cust_selection."',
                                            pin='".$pin_sel."'
                                         WHERE user_id='".$user_id."'";
	//echo "Query:".$query;
                            
        $id = $this->ExecuteQuery($query);
       
        return $id;

    }
   
    public function get_access($user_id){
        $query="SELECT * FROM ".TBL_USER_LEVEL." WHERE user_id='".$user_id."'";
	        $values=$this->SimpleQuery($query);
        return $values;
    }
    public function getMenu($id)
    {
        global $commonFunction;
        $menuArr = array();
        $arr=array();
        $select=array();
        if(isset($_GET['url']))
        {

            $arr = explode('/', $_GET['url']);

		    $query = "SELECT * FROM ".TBL_MENU." WHERE parent=0 AND controller = '".$arr[0]."' and user_id='".$id."'";
          $menuItem = $this->SimpleQuery($query);
            $i = 0;
            foreach($menuItem as $mitem)
            {
                $menuArr[$i]['name'] = $mitem['name'];
                $menuArr[$i]['url'] = $mitem['controller'].'/'.$mitem['slug'];
                $menuArr[$i]['parent'] = '0';
                $menuArr[$i]['id'] = $mitem['id'];
                //if($mitem['name']!=0)
                {
                    $query = "SELECT * FROM ".TBL_MENU." WHERE parent = ".$mitem['id']." AND controller = '".$arr[0]."' and user_id='".$id."'";
                    $submenuItems = $this->SimpleQuery($query);
                    if(!empty($submenuItems))
                    {
                        $j =0 ;
                        foreach($submenuItems as $sitem)
                        {
                            $menuArr[$i]['submenu'][$j]['name'] = $sitem['name'];
                            $menuArr[$i]['submenu'][$j]['id'] = $sitem['id'];
                            $menuArr[$i]['submenu'][$j]['url'] = $sitem['controller'].'/'.$sitem['slug'];
                            $menuArr[$i]['submenu'][$j]['parent'] = $i;
                            $j++;
                        }
                    }
                    $i++;
                }
            }
        }
        return $menuArr;
    }
                
     
    public function add_menu($user_id,&$select,&$slug)
    {


$length=count($select);

for($i=0;$i<$length;$i++){

        $query = "INSERT INTO ".TBL_MENU."
                                    (   user_id,
                                        name,
                                        controller,
                                        slug,
                                        parent
                                       )
                                    VALUES
                                    (
                                        '".$user_id."',
                                        '".$select[$i]."',
                                        'admin',
                                        '".$slug[$i]."',
                                        '0'
                                     )";
        $id = $this->ExecuteQuery($query);

             if($slug[$i]=="creditlog"){
        		$query="SELECT * FROM ".TBL_MENU." where slug='customers' and user_id='".$user_id."'";
        		$values=$this->SimpleQuery($query);
            			foreach ($values as $key => $value) {
   
				   $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
       					 $this->ExecuteQuery($query);
   
         			   }
        }
            else if($slug[$i]=="customersku" || $slug[$i]=="vendorsku" || $slug[$i]=="pins"){
                     	$query="SELECT * FROM ".TBL_MENU." where slug='#' and user_id='".$user_id."'";
        		$values=$this->SimpleQuery($query);
            		foreach ($values as $key => $value) {
   
			       $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
       				 $this->ExecuteQuery($query);
   
            		} 
        }
            else if( $slug[$i]=="transactions/export" || $slug[$i]=="transactions/summary")
                {
                                $query="SELECT * FROM ".TBL_MENU." where slug='transactions' and user_id='".$user_id."'";
        			$values=$this->SimpleQuery($query);
           			 foreach ($values as $key => $value) {
   
   
                 			 $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
       				 $this->ExecuteQuery($query);
   
        			  }
    
       		 }
    }
}   

public function update_menu($user_id,&$select,&$slug)
    {

$length=count($select);

   $query="DELETE FROM ".TBL_MENU." WHERE user_id='".$user_id."'";
	
   $this->ExecuteQuery($query);


for($i=0;$i<$length;$i++){

        $query = "INSERT INTO ".TBL_MENU."
                                    (   user_id,
                                        name,
                                        controller,
                                        slug,
                                        parent
                                       )
                                    VALUES
                                    (
                                        '".$user_id."',
                                        '".$select[$i]."',
                                        'admin',
                                        '".$slug[$i]."',
                                        '0'
                                        )";
	

        $id = $this->ExecuteQuery($query);

             if($slug[$i]=="creditlog"){
        $query="SELECT * FROM ".TBL_MENU." where slug='customers' and user_id='".$user_id."'";
        $values=$this->SimpleQuery($query);
            foreach ($values as $key => $value) {
   
   
                  $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
        $this->ExecuteQuery($query);
   
            }
        }
            else if($slug[$i]=="customersku" || $slug[$i]=="vendorsku" || $slug[$i]=="pins"){
                     $query="SELECT * FROM ".TBL_MENU." where slug='#' and user_id='".$user_id."'";
        $values=$this->SimpleQuery($query);
            foreach ($values as $key => $value) {
   
   
                  $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
        $this->ExecuteQuery($query);
   
            } 
        }
            else if( $slug[$i]=="transactions/export" || $slug[$i]=="transactions/summary")
                {
                                $query="SELECT * FROM ".TBL_MENU." where slug='transactions' and user_id='".$user_id."'";
        $values=$this->SimpleQuery($query);
            foreach ($values as $key => $value) {
   
   
                  $query = "UPDATE ".TBL_MENU." SET
                                        parent = '".$value['id']."'
                                        where
                                        user_id='".$user_id."' and slug='".$slug[$i]."'";
        $this->ExecuteQuery($query);
   
          }
    
        }
  
       }
        

    }
    public function getUser($id)
    {
    
       $query = "SELECT * FROM ".TBL_USER." WHERE id='".$id."'";
       $user = $this->SimpleQuery($query);
       return $user;
    }

    public function getUserList()
    {
            

      $query = "SELECT * FROM ".TBL_USER;
           
      $user = $this->SimpleQuery($query);
       return $user;
    }

    public function user_delete($id)
    {
         $query = "UPDATE ".TBL_USER."
                      SET
                      status='0'
                      WHERE id=".$id." ";
       $this->ExecuteQuery($query);


    }
    

}