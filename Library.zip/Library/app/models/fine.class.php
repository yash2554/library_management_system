<?php

class Fine extends DBAccess
{
    public function login_admin($username,$password)
    {
        $query = "SELECT * FROM ".TBL_ADMIN." WHERE username='".$username."' AND password='".md5($password)."'";
        echo $query;
        $user = $this->SimpleQuery($query);
        return $user;
    }
      public function login_reader($username)
    {
        $query = "SELECT * FROM ".TBL_READER." WHERE idReader='".$username."'";
        $user = $this->SimpleQuery($query);
        return $user;
    }

    public function getUser($uid)
    {
    	$query = "SELECT * FROM ".TBL_USER." WHERE id='".$uid."' AND status=1";
        $user = $this->SimpleQuery($query);
        return $user;
    }

    public function updatePassword($password)
    {
        $query = "UPDATE ".TBL_USER." SET password='".md5($password)."' WHERE id='".$_SESSION['admin']['logged_in']."'";
        $user = $this->ExecuteQuery($query);
        return $user;
    }

}
