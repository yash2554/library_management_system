<?php

class Branch extends DBAccess
{
    public function addSkuByAPI($vendor_id,$sku_code,$sku_name,$type,$min_amount,
                                $max_amount,$vendor_mapped_amount,$is_sales_tax_charged,$discount,
                                $exchange_rate,$t_exchange_rate,$fees,$operator_id,$allow_decimal,$carrier_name,
                                $bonus_amount,$local_number_length,$currency,$country)
    {
        $query = "INSERT INTO ".TBL_VENDOR_SKU."
        							(
        							 	vendor_id,
        							 	sku_code,
        							 	sku_name,
        							 	type,
        							 	min_amount,
        							 	max_amount,
        							 	vendor_mapped_amount,
        							 	is_sales_tax_charged,
        							 	discount,
        							 	exchange_rate,
        							 	t_exchange_rate,
        							 	fees,
        							 	operator_id,
        							 	allow_decimal,
        							 	carrier_name,
        							 	bonus_amount,
        							 	local_number_length,
        							 	currency,
        							 	country
        							)
    								VALUES
    								(
    								 	'".$vendor_id."',
    								 	'".$sku_code."',
    								 	'".$sku_name."',
    								 	'".$type."',
    								 	'".$min_amount."',
    								 	'".$max_amount."',
    								 	'".$vendor_mapped_amount."',
    								 	'".$is_sales_tax_charged."',
    								 	'".$discount."',
    								 	'".$exchange_rate."',
    								 	'".$t_exchange_rate."',
    								 	'".$fees."',
    								 	'".$operator_id."',
    								 	'".$allow_decimal."',
    								 	'".$carrier_name."',
    								 	'".$bonus_amount."',
    								 	'".$local_number_length."',
    								 	'".$currency."',
    								 	'".$country."'
    								 )";
        $this->ExecuteQuery($query);
    }

    public function add_vendor($v_name,$u_name,$password,$priority,$url,$address,$city,$state,$fax,$email,$modified_by,$created_by,$created_on)
    {

      $query = "INSERT INTO ".TBL_VENDOR."
               (name,
                username,
                password,
                priority,
                url,
                address,
                city,
                state,
                fax,
                email,
                modified_by,
                created_by,
                created_on,
                status)
                VALUES
               ('".$v_name."',
                '".$u_name."',
                '".$password."',
                '".$priority."',
                '".$url."',
                '".$address."',
                '".$city."',
                '".$state."',
                '".$fax."',
                '".$email."',
                '".$modified_by."',
                '".$created_by."',
                '".$created_on."',
                '1')";
         $this->ExecuteQuery($query);
    }

    public function getVendor($id)
    {
        $query = "SELECT * FROM ".TBL_VENDOR." WHERE id='".$id."' AND status=1";
        $vendor = $this->SimpleQuery($query);
        return $vendor;
    }

    public function getVendorSKU($sku_code)
    {
        $query = "SELECT * FROM ".TBL_VENDOR_SKU." WHERE sku_code='".$sku_code."' AND status=1";
        $vendor = $this->SimpleQuery($query);
        return $vendor;
    }

    public function getVendorSKU2($sku_code,$amount,$vendor_id)
    {
        $query = "SELECT * FROM ".TBL_VENDOR_SKU." WHERE
                    sku_code='".$sku_code."' AND
                    min_amount>='".$amount."' AND
                    max_amount<='".$amount."' AND
                    vendor_id=".$vendor_id." AND
                    status=1";
        $vendor = $this->SimpleQuery($query);
        return $vendor;
    }

    public function updateVendor($id,$v_name,$u_name,$password,$url,
                                    $address,$city,$state,$fax,$email,
                                    $modified_by,$modified_on,$priority="")
    {
        $field = "";
        if($priority!="")
        {
            $field .= ',priority='.$priority;
            $query = "UPDATE ".TBL_VENDOR_SKU." SET priority='".$priority."' WHERE vendor_id='".$id."'";
            $this->ExecuteQuery($query);
        }
        $query = "UPDATE ".TBL_VENDOR."
                      SET
                      name='".$v_name."',
                      username='".$u_name."',
                      password='".$password."',
                      url='".$url."',
                      address='".$address."',
                      city='".$city."',
                      state='".$state."',
                      fax='".$fax."',
                      email='".$email."',
                      modified_by='".$modified_by."',
                      modified_on='".$modified_on."'
                      ".$field."
                      WHERE id=".$id." ";
        $this->ExecuteQuery($query);
    }

    public function getVendorList()
    {
        $query = "SELECT * FROM ".TBL_VENDOR." WHERE status=1";
        $vendor = $this->SimpleQuery($query);
        return $vendor;
    }

    public function vendor_delete($id)
    {
        $query = "UPDATE ".TBL_VENDOR."
                      SET
                      status='0'
                      WHERE id=".$id." ";
       $this->ExecuteQuery($query);
    }

    public function insertVendorTransaction($respArr)
    {
        $query = "INSERT INTO ".TBL_VENDOR_TRANSACTION."
                                    (
                                        customer_transaction_id,
                                        vendor_id,
                                        vendor_sku_id,
                                        vendor_sku,
                                        vendor_transaction_id,
                                        vender_amount,
                                        vendor_invoice_amount,
                                        recharge_topup_amount,
                                        vendor_topup_tax,
                                        recharge_topup_currency,
                                        vendor_pin,
                                        vendor_pin_instructions,
                                        vendor_transaction_status,
                                        vendor_response_code,
                                        vendor_error_reason,
                                        datetime
                                    )
                                    VALUES
                                    (
                                        '".$respArr['customer_transaction_id']."',
                                        '".$respArr['vendor_id']."',
                                        '".$respArr['vendor_sku_id']."',
                                        '".$respArr['vendor_sku']."',
                                        '".$respArr['vendor_transaction_id']."',
                                        '".$respArr['vendor_amount']."',
                                        '".$respArr['vendor_invoice_amount']."',
                                        '".$respArr['recharge_topup_amount']."',
                                        '".$respArr['recharge_topup_tax']."',
                                        '".$respArr['recharge_topup_currency']."',
                                        '".$respArr['vendor_pin']."',
                                        '".$respArr['vendor_pin_instructions']."',
                                        '".$respArr['vendor_transaction_status']."',
                                        '".$respArr['response_code']."',
                                        '".$respArr['response_message']."',
                                        '".$respArr['vendor_transaction_time']."'
                                     )";
	//error_log("Vendor query:".$query);
        $this->ExecuteQuery($query);
    }
}