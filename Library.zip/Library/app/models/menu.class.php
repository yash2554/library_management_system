<?php
class Menu extends DBAccess
{

    public function getMenu()
    {
        global $commonFunction;
        $menuArr = array();
        $arr=array();
   
  //   $controller=$_SESSION['controller']['logged_in'];
    

        if(isset($_GET['url']))
        {
            $arr = explode('/', $_GET['url']);
		
            $query = "SELECT * FROM ".TBL_MENU." WHERE parent=0 AND controller = '".$arr[0]."'";
          $menuItem = $this->SimpleQuery($query);
            $i = 0;
            foreach($menuItem as $mitem)
            {
                $menuArr[$i]['name'] = $mitem['name'];
                $menuArr[$i]['url'] = $mitem['controller'].'/'.$mitem['slug'];
                $menuArr[$i]['parent'] = '0';
                $menuArr[$i]['id'] = $mitem['id'];
                //if($mitem['name']!=0)
                {
                    $query = "SELECT * FROM ".TBL_MENU." WHERE parent = ".$mitem['id']." AND controller = '".$arr[0]."'";
                    $submenuItems = $this->SimpleQuery($query);
                    if(!empty($submenuItems))
                    {
                        $j =0 ;
                        foreach($submenuItems as $sitem)
                        {
                            $menuArr[$i]['submenu'][$j]['name'] = $sitem['name'];
                            $menuArr[$i]['submenu'][$j]['id'] = $sitem['id'];
                            $menuArr[$i]['submenu'][$j]['url'] = $sitem['controller'].'/'.$sitem['slug'];
                            $menuArr[$i]['submenu'][$j]['parent'] = $i;
                            $j++;
                        }
                    }
                    $i++;
                }
            }
        }
        return $menuArr;
    }
}