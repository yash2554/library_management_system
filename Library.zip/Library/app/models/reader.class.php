<?php

class Reader extends DBAccess {

    public function authenticate($username) {
        $query = "SELECT * FROM " . TBL_READER . " WHERE idreader='" . $username . "'";
        $reader = $this->SimpleQuery($query);
        return $reader;
    }

    public function insertCustomerTransaction($transaction_id, $customer_id, $customer_sku_id, $customer_sku, $mobile, $customer_amount, $customer_discount, $customer_invoice_amount, $response_code = "") {
        $query = "INSERT INTO " . TBL_CUSTOMER_TRANSACTION . "
                                    (
                                        transaction_id,
                                        customer_id,
                                        customer_sku_id,
                                        customer_sku,
                                        customer_amount,
                                        customer_discount,
                                        customer_invoice_amount,
                                        mobile_number,
                                        response_code
                                    )
                                    VALUES
                                    (
                                        '" . $transaction_id . "',
                                        '" . $customer_id . "',
                                        '" . $customer_sku_id . "',
                                        '" . $customer_sku . "',
                                        '" . $customer_amount . "',
                                        '" . $customer_discount . "',
                                        '" . $customer_invoice_amount . "',
                                        '" . $mobile . "',
                                        '" . $response_code . "'
                                     )";
        $customer_trans_id = $this->ExecuteQuery($query);
        return $customer_trans_id;
    }

    public function updateCustomerTransaction($transaction_id, $recharge_topup_amount, $recharge_topup_currency, $recharge_topup_tax, $pin_number = NULL, $pin_instructions = NULL, $response_code = 999) {
        $query = "UPDATE " . TBL_CUSTOMER_TRANSACTION . " SET
                                        recharge_topup_amount = '" . $recharge_topup_amount . "',
                                        recharge_topup_currency = '" . $recharge_topup_currency . "',
                                        recharge_topup_tax = '" . $recharge_topup_tax . "',
                                        pin_number = '" . $pin_number . "',
                                        pin_instructions = '" . $pin_instructions . "',
                                        response_code = '" . $response_code . "'
                                    WHERE id=" . $transaction_id . " ";
        //error_log($query);
        $this->ExecuteQuery($query);
    }

    public function add_customer($cname, $fname, $lname, $uname, $password, $address, $city, $state, $zip, $email, $credit_limit, $daily_limit, $status, $modifyby, $createdby, $createdon) {
        $query = "INSERT INTO " . TBL_CUSTOMERS . "
                                    (   company_name,
                                        fname ,
                                        lname,
                                        email ,
                                        address ,
                                        city,
                                        state,
                                        zip,
                                        username,
                                        password,
                                        credit_limit,
                                        daily_limit,
                                        status,
                                        modified_by,
                                        created_by,
                                        created_on,
                                        is_deleted
                                    )
                                    VALUES
                                    (
                                        '" . $cname . "',
                                        '" . $fname . "',
                                        '" . $lname . "',
                                        '" . $email . "',
                                        '" . $address . "',
                                        '" . $city . "',
                                        '" . $state . "',
                                        '" . $zip . "',
                                        '" . $uname . "',
                                        '" . $password . "',
                                        '" . $credit_limit . "',
                                        '" . $daily_limit . "',
                                        '" . $status . "',
                                        '" . $modifyby . "',
                                        '" . $createdby . "',
                                        '" . $createdon . "',
                                        '0'
                                     )";
        $customer_id = $this->ExecuteQuery($query);
        return $customer_id;
    }

    public function getCustomer($id) {
        if ($_SESSION['admin']['username'] != "admin") {
            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE id='" . $id . "' AND is_deleted=0 AND created_by='" . $_SESSION['admin']['logged_in'] . "'";
        } else {
            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE id='" . $id . "' AND is_deleted=0 ";
        }
        $customer = $this->SimpleQuery($query);
        return $customer;
    }

    public function getCustomerList() {
        if ($_SESSION['admin']['username'] != "admin") {

            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE  is_deleted=0 AND created_by='" . $_SESSION['admin']['logged_in'] . "'";
        } else {
            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE  is_deleted=0";
        }
        $customer = $this->SimpleQuery($query);
        return $customer;
    }

    public function update_customer($id, $cname, $fname, $lname, $uname, $password, $address, $city, $state, $zip, $email, $credit_limit, $daily_limit, $status, $modifyby, $modifyon) {
        $query = "UPDATE " . TBL_CUSTOMERS . " SET
                                        company_name='" . $cname . "',
                                        fname='" . $fname . "',
                                        lname='" . $lname . "',
                                        email='" . $email . "',
                                        address='" . $address . "',
                                        city='" . $city . "',
                                        state='" . $state . "',
                                        zip='" . $zip . "',
                                        username='" . $uname . "',
                                        password='" . $password . "',
                                        credit_limit='" . $credit_limit . "',
                                        daily_limit='" . $daily_limit . "',
                                        status='" . $status . "',
                                        modified_by='" . $modifyby . "',
                                        modified_on='" . $modifyon . "'
                                        WHERE id=" . $id . " 
					 ";
        $this->ExecuteQuery($query);
    }

    public function customers() {
        if ($_SESSION['admin']['username'] != "admin") {

            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE is_deleted=0 AND created_by='" . $_SESSION['admin']['logged_in'] . "'";
        } else {
            $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE is_deleted=0";
        }
        $customer = $this->SimpleQuery($query);
        return $customer;
    }

    public function customer_delete($id) {
        $query = "UPDATE " . TBL_CUSTOMERS . "
                      SET
                      is_deleted='1'
                      WHERE id=" . $id . " 
			";
        $this->ExecuteQuery($query);
    }

    ################# Credit_log###################################

    public function creditlog_add($cname, $amount, $comment, $created_by) {
        $query = "INSERT INTO " . TBL_CUSTOMER_CREDIT_LOG . "
                                (   customer_id,
                                    amount,
                                    comment,
				    created_by
                                 )
                                 VALUES
                                 (
                                    '" . $cname . "',
                                    '" . $amount . "',
                                    '" . $comment . "',
				'" . $created_by . "'
                                  )";
        $customers = $this->ExecuteQuery($query);
        return $customers;
    }

    public function creditlogs() {
        if ($_SESSION['admin']['username'] == "admin") {
            $query = "SELECT a.*,b.fname as f_name,b.lname as l_name FROM " . TBL_CUSTOMER_CREDIT_LOG . "  as a join " . TBL_CUSTOMERS . " as b on a.customer_id=b.id";
        } else {
            $query = "SELECT a.*,b.fname as f_name,b.lname as l_name FROM " . TBL_CUSTOMER_CREDIT_LOG . "  as a join " . TBL_CUSTOMERS . " as b on a.customer_id=b.id and a.created_by='" . $_SESSION['admin']['logged_in'] . "'";
        }
        $creditlog = $this->SimpleQuery($query);
        return $creditlog;
    }

    public function getCreditlog($id) {
        if ($_SESSION['admin']['username'] == "admin") {
            $query = "SELECT * FROM " . TBL_CUSTOMER_CREDIT_LOG . " WHERE id='" . $id . "' ";
        } else {
            $query = "SELECT * FROM " . TBL_CUSTOMER_CREDIT_LOG . " WHERE id='" . $id . "' and created_by='" . $_SESSION['admin']['logged_in'] . "'";
        }
        $creditlog = $this->SimpleQuery($query);
        return $creditlog;
    }

    public function creditlog_update($id, $cname, $amount, $comment) {
        $query = "UPDATE " . TBL_CUSTOMER_CREDIT_LOG . " SET
                                        customer_id = '" . $cname . "',
                                        amount = '" . $amount . "',
                                        comment = '" . $comment . "'
                                       WHERE id = " . $id . " ";
        $this->ExecuteQuery($query);
    }

    ###########################################Credit LOg End##################################

    public function checkDailyUsage($customer_id) {
        $date = date('Y-m-d 00:00:00', time());
        // $date = "2013-10-15 00:00:00";
        $query = "SELECT SUM(customer_invoice_amount) AS used FROM " . TBL_CUSTOMER_TRANSACTION . " WHERE response_code='000' AND datetime>='" . $date . "' AND customer_id=" . $customer_id . " ";
        $customer = $this->SimpleQuery($query);
        $amount = 0;
        if ($customer[0]['used'] != NULL) {
            $amount = $customer[0]['used'];
        }
        return $amount;
    }

    public function checkLimits($customer_id, $invoice_amount) {
        $output = array();
        $query = "SELECT * FROM " . TBL_CUSTOMERS . " WHERE id=" . $customer_id . " ";
        $customer = $this->SimpleQuery($query);
        $credit_limit = $customer[0]['credit_limit'];
        $daily_limit = $customer[0]['daily_limit'];
        $credit_used = $customer[0]['credit_used'];
        $todays_usage = $this->checkDailyUsage($customer_id);
        if ($credit_limit < $credit_used + $invoice_amount) {
            $has_credit = 0;
        } else {
            $has_credit = 1;
        }
        if ($daily_limit < $todays_usage + $invoice_amount) {
            $daily_limit_reached = 1;
        } else {
            $daily_limit_reached = 0;
        }
        if ($has_credit && !$daily_limit_reached) {
            $output['is_allowed'] = 1;
        } else {
            $output['is_allowed'] = 0;
        }
        $output['has_credit'] = $has_credit;
        $output['daily_limit_reached'] = $daily_limit_reached;
        return $output;
    }

    public function updateCreditUsed($customer_id, $invoice_amount) {
        $query = "UPDATE " . TBL_CUSTOMERS . " SET credit_used=credit_used+" . $invoice_amount . " WHERE id=" . $customer_id;
        $customer = $this->ExecuteQuery($query);
    }

    public function getTransactions($value = '') {
        $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            ST.sku_type,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            OP.name as operator,
                            EC.error_message
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                    LEFT JOIN " . TBL_CUSTOMERS . " AS CU ON CT.customer_id = CU.id
                    LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VS.id = VT.vendor_sku_id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id
                    LEFT JOIN " . TBL_ERROR_CODES . " as EC on CT.response_code=EC.error_code
                    ORDER BY id DESC";
        $transactions = $this->SimpleQuery($query);
        return $transactions;
    }

    public function filterTransactions($search) {

        $condition = "";


        if ($search['customer'] != "") {
            $condition .= ' AND CU.company_name LIKE "%' . $search['customer'] . '%"';
        }

        if ($search['sku'] != "") {
            $condition .= ' AND CT.customer_sku LIKE "%' . $search['sku'] . '%"';
        }

        if ($search['sku_name'] != "") {
            $condition .= ' AND CS.name LIKE "%' . $search['sku_name'] . '%"';
        }

        if ($search['type'] != "") {
            $condition .= ' AND ST.sku_type LIKE "%' . $search['type'] . '%"';
        }

        if ($search['country'] != "") {
            $condition .= ' AND CS.country="' . $search['country'] . '"';
        }

        if ($search['operator'] != "") {
            $condition .= ' AND OP.name LIKE "%' . $search['operator'] . '%"';
        }

        if ($search['from_amount'] != "") {
            $condition .= ' AND CT.customer_amount>=' . $search['amount'];
        }

        if ($search['to_amount'] != "") {
            $condition .= ' AND CT.customer_amount<=' . $search['amount'];
        }

        if ($search['from_inv_amount'] != "") {
            $condition .= ' AND CT.customer_invoice_amount>=' . $search['from_inv_amount'];
        }

        if ($search['to_inv_amount'] != "") {
            $condition .= ' AND CT.customer_invoice_amount<=' . $search['to_inv_amount'];
        }

        if ($search['mobile'] != "") {
            $condition .= ' AND CT.mobile_number LIKE "%' . $search['mobile'] . '%"';
        }

        if ($search['vendor'] != "") {
            $condition .= ' AND VE.name LIKE "%' . $search['vendor'] . '%"';
        }

        if ($search['from_vendor_amount'] != "") {
            $condition .= ' AND VT.vender_amount>=' . $search['from_vendor_amount'];
        }

        if ($search['to_vendor_amount'] != "") {
            $condition .= ' AND VT.vender_amount<=' . $search['to_vendor_amount'];
        }

        if ($search['from_vendor_inv_amount'] != "") {
            $condition .= ' AND VT.vendor_invoice_amount>=' . $search['from_vendor_inv_amount'];
        }

        if ($search['to_vendor_inv_amount'] != "") {
            $condition .= ' AND VT.vendor_invoice_amount<=' . $search['to_vendor_inv_amount'];
        }

        if ($search['from_recharge_amt'] != "") {
            $condition .= ' AND CT.recharge_topup_amount>=' . $search['from_recharge_amt'];
        }

        if ($search['to_recharge_amt'] != "") {
            $condition .= ' AND CT.recharge_topup_amount<=' . $search['to_recharge_amt'];
        }

        if ($search['pin'] != "") {
            $condition .= ' AND CT.pin_number LIKE "%' . $search['pin'] . '%"';
        }

        if ($search['status'] != "") {
            if ($search['status'] == "1") {
                $condition .= ' AND CT.response_code="000"';
            } else {
                $condition .= ' AND CT.response_code!="000"';
            }
        }


        $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            ST.sku_type,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            OP.name AS operator
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                    LEFT JOIN " . TBL_CUSTOMERS . " AS CU ON CT.customer_id = CU.id
                    LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VS.sku_code = VT.vendor_sku AND VS.vendor_id = VT.vendor_id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id
                    WHERE 1=1 " . $condition . "
                    ORDER BY id DESC";
        $transactions = $this->SimpleQuery($query);
        return $transactions;
    }

    public function getTransactionDate($from = "", $to = "") {
        if ($from != "" && $to != "") {
            $dateQuery = " WHERE date(CT.datetime)>='" . $from . "' AND date(CT.datetime)<='" . $to . "' ";
            // $dateQuery = " WHERE CT.datetime>='".$from."' AND CT.datetime<='".$to."' ";
        } else {
            $dateQuery = " ";
        }
        $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            ST.sku_type,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            VS.currency,
                            OP.name AS operator
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                    LEFT JOIN " . TBL_CUSTOMERS . " AS CU ON CT.customer_id = CU.id
                    LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VS.sku_code = VT.vendor_sku AND VS.vendor_id = VT.vendor_id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id
                    " . $dateQuery . "
                    GROUP BY CT.id
                    ORDER BY CT.datetime DESC";
	error_log("query:".$query);
        $transactions = $this->SimpleQuery($query);
        return $transactions;
    }

    public function getTransactionDateReport($date) {
        // $dateQuery = " ";
        $dateQuery = " WHERE date(CT.datetime) = '" . $date . "' "; //'".date("Y-m-d")."'

        $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            VE.id AS vendor_id,
                            ST.id AS sku_type_id,
                            ST.sku_type,
                            CS.id AS customer_sku_id,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.id AS customer_id,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            VS.currency,
                            OP.id AS operator_id,
                            OP.name AS operator
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                    LEFT JOIN " . TBL_CUSTOMERS . " AS CU ON CT.customer_id = CU.id
                    LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VS.sku_code = VT.vendor_sku AND VS.vendor_id = VT.vendor_id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id
                    " . $dateQuery . "
                    GROUP BY CT.id
                    ORDER BY CT.datetime DESC";
        $transactions = $this->SimpleQuery($query);
        return $transactions;
    }

    public function insertCronData($insert_cron_data) {
        $this->ExecuteQuery($insert_cron_data);
        return true;
    }

    public function transactionSummary($request) {

        $condition = "";
        // $condition .= " AND VS.is_delete=0";

        if ($request['from_date'] != "") {
            $from = date("Y-m-d H:i:m", strtotime($request['from_date']));
            $condition .= " AND CT.datetime>='" . $from . "'";
        }

        if ($request['to_date'] != "") {
            $to = date("Y-m-d H:i:m", strtotime($request['to_date']));
            $condition .= " AND CT.datetime<='" . $to . "'";
        }
        if ($_SESSION['admin']['username'] == "admin") {

            if ($request['vendor'] != 0) {
                $condition .= " AND VE.id='" . $request['vendor'] . "'";
            }



            if ($request['customer'] != 0) {
                $condition .= " AND CU.id='" . $request['customer'] . "'";
            }

            if ($request['service_type'] != 0) {
                $condition .= " AND ST.id='" . $request['service_type'] . "'";
            }

            if ($request['country'] != 0) {
                $condition .= " AND CU.id='" . $request['country'] . "'";
            }

            if ($request['sku_name'] != 0) {
                $condition .= " AND CS.id='" . $request['sku_name'] . "'";
            }

            if ($request['operator'] != 0) {
                $condition .= " AND OP.id='" . $request['operator'] . "'";
            }
        }
        $group = "GROUP BY CT.id";

        $order = "";
        $extra_select = "";
        // $condition_amount = "AND ((VS.vendor_mapped_amount=CS.vendor_mapped_amount AND VS.type=1)
        //                     OR
        //                     (
        //                         VS.min_amount<=CT.customer_amount
        //                         AND VS.max_amount>=CT.customer_amount
        //                         AND VS.type=2
        //                     ))";
        // $condition_amount = "AND VT.vendor_sku_id = VS.id";
        if ($_SESSION['admin']['username'] == "admin") {
            switch ($request['group']) {
                case 1:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $order = " CT.datetime DESC,";
                    $group = " GROUP BY DATE(CT.datetime)";
                    $condition .= " AND CT.response_code='000'";
                    break;

                case 2:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $order = " ST.sku_type ASC,";
                    $group = " GROUP BY ST.sku_type";
                    $condition .= " AND CT.response_code='000'";
                    break;

                case 3:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $order = " CS.country ASC,";
                    $group = " GROUP BY CS.country";
                    $condition .= " AND CT.response_code='000'";
                    break;

                case 4:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $group = " GROUP BY OP.name";
                    $order = " OP.name ASC,";
                    $condition .= " AND CT.response_code='000'";
                    break;

                case 5:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $group = " GROUP BY VE.id";
                    $order = " VE.name ASC,";
                    $condition .= " AND CT.response_code='000'";
                    break;

                case 6:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $group = " GROUP BY CU.company_name";
                    $condition .= " AND CT.response_code='000'";
                    $order = " CU.company_name ASC,";
                    break;

                case 7:
                    $extra_select .= " ,SUM(CT.customer_amount) AS sum_customer_amount";
                    $extra_select .= " ,SUM(CT.customer_invoice_amount) AS sum_customer_invoice_amount";
                    $extra_select .= " ,SUM(VT.vender_amount) AS sum_vendor_amount";
                    $extra_select .= " ,SUM(VT.vendor_invoice_amount) AS sum_vendor_invoice_amount";
                    $group = " GROUP BY CS.name";
                    $condition .= " AND CT.response_code='000'";
                    $order = " CS.name ASC,";
                    break;

                default:
                    //Do Nothing for no grouping
                    break;
            }
            $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            VE.id AS vendor_id,
                            ST.sku_type,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            VS.currency,
                            OP.name AS operator,
                            COUNT(CT.id) AS transaction_count
                            " . $extra_select . "
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                    LEFT JOIN " . TBL_CUSTOMERS . " AS CU ON CT.customer_id = CU.id
                    LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VT.vendor_sku_id = VS.id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id
                    WHERE 1=1 " . $condition . "
                    " . $group . "
                    ORDER BY " . $order . "CT.datetime DESC";
    } else {


		
                        $custID=$this->getCustomerId($_SESSION['admin']['logged_in']);
		$id=$custID[0]['customer_id'];
	            $query = "SELECT    CT.*,
                            VT.vendor_error_reason,
                            VE.name AS vendor,
                            VE.id AS vendor_id,
                            ST.sku_type,
                            CS.name AS customer_sku_name,
                            CS.country,
                            VT.vendor_sku,
                            VT.vender_amount,
                            VT.vendor_invoice_amount,
                            CU.company_name,
                            VS.sku_code,
                            VS.sku_name,
                            VS.currency,
                            OP.name AS operator,
                            COUNT(CT.id) AS transaction_count
                            " . $extra_select . "
                    FROM " . TBL_CUSTOMER_TRANSACTION . " AS CT
                    LEFT JOIN " . TBL_VENDOR_TRANSACTION . " AS VT ON CT.id = VT.customer_transaction_id
                     LEFT JOIN " . TBL_CUSTOMER_SKU . " AS CS ON CS.id = CT.customer_sku_id
                    LEFT JOIN " . TBL_VENDOR_SKU . " AS VS ON VT.vendor_sku_id = VS.id
                    LEFT JOIN " . TBL_VENDOR . " AS VE ON VE.id = VS.vendor_id
                    LEFT JOIN " . TBL_SKU_TYPE . " as ST on CS.type=ST.id
                    LEFT JOIN " . TBL_OPERATOR . " as OP on CS.operator_id=OP.id,
                    " . TBL_CUSTOMERS . " as CU 
                    WHERE CT.customer_id=" . $id. " and 1=1 " . $condition . "
                    " . $group . "
                    ORDER BY " . $order . "CT.datetime DESC";
	}
         
   
        $transactions = $this->SimpleQuery($query);
        return $transactions;
    }
 public function getCustomerId($id){
        $query="SELECT * FROM ".TBL_USER." WHERE id=".$id;
        $id=  $this->SimpleQuery($query);
	return $id;
    }


}
