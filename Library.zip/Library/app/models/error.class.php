<?php

class Error extends DBAccess
{
    public function getError($error_code)
    {
        $query = "SELECT * FROM ".TBL_ERROR_CODES." WHERE error_code='".$error_code."'";
        $error = $this->SimpleQuery($query);
        if(!empty($error))
        {
            return $error[0]['error_message'];
        }
        else
        {
            return "Unknown Error";
        }

    }

    public function getErrorByVendorCode($vendor_id,$vendor_error_code)
    {
        $query = "SELECT * FROM ".TBL_VENDOR_ERROR_CODES." AS VE
                    LEFT JOIN ".TBL_ERROR_CODES." As EC  ON VE.system_error_code = EC.error_code
                    WHERE vendor_error_code='".$vendor_error_code."'
                    AND vendor_id=".$vendor_id;
        $error = $this->SimpleQuery($query);
        return $error;
    }

}