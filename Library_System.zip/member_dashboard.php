<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: member_login.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");
?>
<html>
<head lang="en">
<link rel="icon" href="" type="image/ico" />
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <title>
        Member DashBoard
    </title>

<script type="text/javascript" src="boot/js/jquery.js"></script>
<script type="text/javascript" src="boot/js-1/jquery.js"></script>
<style>
    .login-panel {
        margin-top: 35px;
</style>
<body>
<div class="container" style="width:1024px">


            <div class="login-panel panel panel-success">
                <div class="panel-heading">
					<h3 class="panel-title"><a href="member_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
				<div class="panel-body">				
				<div id="container" align="center"> 
				<table width="100%" border="0" cellpadding="2" cellspacing="2">
<tr><td colspan="4" align="left" valign="middle"><div style="font-size:15px;">
<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div></div></td></tr>
<tr><td></td></tr>
<tr><td><a class="list-group-item" href="search_book.php">Search a book by ID, title, or publisher name</a></td></tr>
<tr><td><a class="list-group-item" href="book_checkout_cart.php">Book checkout</a></td></tr>
<tr><td><a class="list-group-item" href="book_return.php">Book return</a></td></tr>
<tr><td><a class="list-group-item" href="book_reserve.php">Book reserve</a></td></tr>
<tr><td><a class="list-group-item" href="compute_borrow_list.php">Compute fine for a book copy borrowed by a reader based on the current date</a></td></tr>
<tr><td><a class="list-group-item" href="book_reserve_cart.php">Print the list of book reserved by a reader and their status</a></td></tr>
<tr><td><a class="list-group-item" href="search_publisher.php">Print the book id and titles of books published by a publisher</a></td></tr>
<tr><td><a class="list-group-item" href="logout.php">Quit</a></td></tr>
</table>
</div> <!-- #container -->
</div>
</div>
</div>

</body>
</html>