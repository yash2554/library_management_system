<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");
//if(isset($_POST['search_again']))
//{
//    
//	$query=$_POST['title'];
	//echo $query;
	$user=$_SESSION['userid'];
	$check_book="select count(*) as c,r.reader_fname,br.lib_name,r.reader_email,r.reader_phone from borrow as bo,reader as r,branch as br,book where (br.lib_id=bo.lib_id and r.reader_id=bo.reader_id and book.book_id=bo.book_id)group by bo.reader_id order by c desc limit 0,10";
   //    echo $check_book;
    $run_book=$dbcon->query($check_book);
	
 
               while($fields = mysqli_fetch_assoc($run_book))
        {
            $values[] = $fields;
         
        }
//        print_r($values);

//}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryi/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Top 10 Borrowers</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>


<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="librarian_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="librarian_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="branch_info.php">Branch Search</a></li>
								<li><a href="search_member.php">Member Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
						
    <div class="container" style="width:1024px;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4" style="width:900px;margin-left: 20px;">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Top 10 Borrowers</a></h3>
                </div>
                <div class="panel-body">
						<fieldset>
						<table align="" class="col-md-12 table-striped table-condensed cf">
                                                    <tr>
                                                        <th>Borrower's Name</th>
                                                        <th>Borrower's Email</th>
                                                        <th>Borrower's Phone</th>
                                                        <th>Branch Name</th>
                                                        <th>No of Copy</th>
                                                     
                                                    </tr>
                                                    
						<?php if(isset($value))
						{
							if($values!=null){
                                                    
     foreach ($values as $key => $row) {
    
?>
						
                                                <tr>

    
                                                    <td><?php echo $row['reader_fname'];?></td>
                                                    <td><?php echo $row['reader_email'];?></td>
                                                    <td><?php echo $row['reader_phone'];?></td>
                                                    <td><?php echo $row['lib_name'];?></td>
                                                    <td><?php echo $row['c'];?></td>
                                                    
                                                </tr>
                                            <?php    }
                                                }
						}
                                                else{
                                                
                                                    ?>
												<tr>Result Not Found</tr>
                                                <?php
                                                }?>
						</table>
						</br></br></br></br>
						</fieldset>
                </div>
            </div>
        </div>
    </div>
</div>
      </div> <!-- #container -->
					</div>
				</div>
	</div>
</body>

</html>