<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

if(isset($_POST['update']))
{
    $reader_id = $_POST['reader_id'];
	$reader_fname=$_POST['reader_fname'];
	$reader_lname=$_POST['reader_lname'];
	$reader_email=$_POST['reader_email'];
    $reader_add=$_POST['reader_add'];
	$reader_city=$_POST['reader_city'];
	$reader_state=$_POST['reader_state'];
	$reader_zip=$_POST['reader_zip'];
	$reader_phone=$_POST['reader_phone'];
	$reader_que=$_POST['reader_que'];
	$reader_ans=$_POST['reader_ans'];

    
//update the reader into the database.
    $update_reader="UPDATE reader SET reader_email='$reader_email',reader_fname='$reader_fname',reader_lname='$reader_lname',reader_add='$reader_add',reader_city='$reader_city',reader_state='$reader_state',reader_zip='$reader_zip',reader_phone='$reader_phone',reader_que='$reader_que',reader_ans='$reader_ans'	WHERE reader_id='$reader_id'";
    if($dbcon->query($update_reader))
    {	
		echo"<script>alert('Update Successfully')</script>";
		echo"<script>window.open('successful_member.php?email=$reader_email','_self')</script>";
    }
	else
	{
		echo"<script>alert('Server is under maintenance !')</script>";
	}

}else
{
	$reader_email=$_GET['email'];
    //echo $reader_email;
    $check_email_query="select * from reader WHERE reader_email ='$reader_email'";
    $run_query=$dbcon->query($check_email_query);
	
	if ($run_query->num_rows > 0)
    {
		while($row = $run_query->fetch_assoc()) {
        $reader_id = $row["reader_id"];
		$reader_email = $row["reader_email"];
		$reader_fname = $row["reader_fname"];
		$reader_lname = $row["reader_lname"];
		$reader_add = $row["reader_add"];
		$reader_city = $row["reader_city"];
		$reader_state=$row['reader_state'];
		$reader_zip=$row['reader_zip'];
		$reader_phone = $row["reader_phone"];
		$reader_que = $row["reader_que"];
		$reader_ans = $row["reader_ans"];
		}
	} 
	
}

?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Edit Information</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">&lt;&nbsp;Librarian Dashboard</a></h3>
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="edit_member.php">
                        <fieldset>
						
                            <div class="form-group">
                                <input class="form-control" value="<?php echo $reader_id;?>" name="reader_id" type="text" readonly>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_fname;?>" name="reader_fname" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_lname;?>" name="reader_lname" type="text" required>
                            </div>

                            <div class="form-group">
                                <input class="form-control" value="<?php echo $reader_email;?>" name="reader_email" type="email" required autofocus>
                            </div>
					
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_add;?>" name="reader_add" type="text" required autofocus>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_city;?>" name="reader_city" type="text" required autofocus>
                            </div>
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_state;?>" name="reader_state" type="text" required autofocus>
                            </div>
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_zip;?>" name="reader_zip" type="text" required autofocus>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_phone;?>" name="reader_phone" type="text" required autofocus>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_que;?>" name="reader_que" type="text" required autofocus>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $reader_ans;?>" name="reader_ans" type="text" required autofocus>
                            </div>
								
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="update" name="update" >

                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>