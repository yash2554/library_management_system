<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

	$check_book_id="select MAX(book_id) as maxi FROM book";
    $run_book=$dbcon->query($check_book_id);
	if ($run_book->num_rows > 0)
    {
		while($row = $run_book->fetch_assoc()) {
        $book_id = $row["maxi"]+1;
		}
	}
	

if(isset($_POST['add']))
{
    $book_id=$_POST['book_id'];
	$book_title=$_POST['book_title'];
	$book_isbn=$_POST['book_isbn'];
	$book_date=$_POST['book_date'];
	$book_qty=$_POST['book_qty'];
	
	$author_fname=$_POST['author_fname'];
	$author_lname=$_POST['author_lname'];
	$author_add=$_POST['author_add'];
	$author_city=$_POST['author_city'];
	
	$publisher_name=$_POST['publisher_name'];
	$publisher_add=$_POST['publisher_add'];
	$publisher_city=$_POST['publisher_city'];
	
	$librarian_id=$_POST['librarian_id'];
	

	$check_book_query="select * from book WHERE book_title ='$book_title'";
    $run_query=$dbcon->query($check_book_query);
	
	if ($run_query->num_rows > 0)
    {
	echo "<script>alert('Book $book_title is already exist in our database !')</script>";
	echo "<script>window.open('add_book.php','_self')</script>";	
	exit();
    }
	else
	{
	$check_author_query="select * from author WHERE author_fname ='$author_fname' AND author_lname ='$author_lname'";
	$check_publisher_query="select * from publisher WHERE publisher_name ='$publisher_name'";
	$run_author_query=$dbcon->query($check_author_query);
	$run_publisher_query=$dbcon->query($check_publisher_query);
		
	if ($run_author_query->num_rows > 0)
	{
		
	while($row3 = $run_author_query->fetch_assoc()) {
        $author_id = $row3["author_id"];
		echo $author_id;
			}
		}
		else{
	
	$check_author_id="select MAX(author_id) as maxi1 FROM author";
    $run_author=$dbcon->query($check_author_id);
	if ($run_author->num_rows > 0)
    {
		while($row1 = $run_author->fetch_assoc()) {
        $author_id = $row1["maxi1"]+1;
		echo $author_id;
		}
	}
	
	$insert_author="insert into author (author_id,author_fname,author_lname,author_add,author_city) VALUE ('$author_id','$author_fname','$author_lname','$author_add','$author_city')";
	if($dbcon->query($insert_author))
		{	
		echo"<script>alert('Author added Successfully')</script>";
		}
	else{
		echo"Error";
		}
	}
		
	if ($run_publisher_query->num_rows > 0)
	{
		
	while($row4 = $run_publisher_query->fetch_assoc()) {
        $publisher_id = $row4["publisher_id"];
		echo $publisher_id;
			}
		}
	else{
		
	$check_publisher_id="select MAX(publisher_id) as maxi2 FROM publisher";
    $run_publisher=$dbcon->query($check_publisher_id);
	if ($run_publisher->num_rows > 0)
    {
		while($row2 = $run_publisher->fetch_assoc()) {
        $publisher_id = $row2["maxi2"]+1;
		echo $publisher_id;
		}
	}
		
	$insert_publisher="insert into publisher (publisher_id,publisher_name,publisher_add,publisher_city) VALUE ('$publisher_id','$publisher_name','$publisher_add','$publisher_city')";
	if($dbcon->query($insert_publisher))
		{	
		echo"<script>alert('Publisher added Successfully')</script>";
		}
		else{
			echo "Error";
		}
	}
	
	$check_branch_query = "select * from lib_branch WHERE librarian_id='$librarian_id'";
	$run_branch_query = $dbcon->query($check_branch_query);
	if ($run_branch_query->num_rows > 0)
	{
		
	while($row5 = $run_branch_query->fetch_assoc()) {
        $lib_id = $row5["lib_id"];
		echo $lib_id;
			}
	}
	
	$insert_book="insert into book (book_id,book_title,book_isbn,book_date) VALUE ('$book_id','$book_title','$book_isbn','$book_date')";
	$insert_book_pub ="insert into book_pub (book_id,publisher_id,author_id) VALUE ('$book_id','$publisher_id','$author_id')";
	$insert_branch_book ="insert into branch_book (lib_id,book_id,book_qty,reserved_copy) VALUE ('$lib_id','$book_id','$book_qty','0')";
	if($dbcon->query($insert_book))
    {	
		if($dbcon->query($insert_book_pub))
		{
			if($dbcon->query($insert_branch_book))
		{
		echo"<script>alert('Book added Successfully')</script>";
		echo "<script>window.open('librarian_dashboard.php','_self')</script>";	
		}
		}
    }
	else
	{
		echo"<script>alert('Server is under maintenance !')</script>";
	}
	
	}
}

?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Add Book</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">&lt;&nbsp;Librarian Dashboard</a></h3>
                </div>

                <div class="panel-body">
                    <form role="form" method="post" action="add_book.php">
                        <fieldset>
						
                            <div class="form-group">
                                <input class="form-control" value="<?php echo $book_id;?>" name="book_id" type="text" readonly>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Book title" name="book_title" type="text" required>
                            </div>
											
							<div class="form-group">
                                <input class="form-control" placeholder="Book ISBN" name="book_isbn" type="text" required >
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Author Fname" name="author_fname" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Author Lname" name="author_lname" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Author Add" name="author_add" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Author City" name="author_city" type="text" required>
                            </div>
														
                            <div class="form-group">
                                <input class="form-control" placeholder="Publisher Name" name="publisher_name" type="text" required>
                            </div>
														
							<div class="form-group">
                                <input class="form-control" placeholder="Publisher Add" name="publisher_add" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Publisher City" name="publisher_city" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Publication Date" name="book_date" type="date" required>
                            </div>
				
							<div class="form-group">
                                <input class="form-control" placeholder="Book Qty" name="book_qty" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" value="<?php echo $_SESSION['userid'];?>" name="librarian_id" type="text" readonly>
                            </div>	
							
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="add" name="add" >

                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>