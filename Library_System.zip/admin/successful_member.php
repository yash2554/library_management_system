<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

if(isset($_POST['done']))
{
	header("Location: librarian_dashboard.php");//redirect to login page to secure the welcome page without login access.
}  
	$reader_email=$_GET['email'];
    
    $check_email_query="select * from reader WHERE reader_email ='$reader_email'";
    $run_query=$dbcon->query($check_email_query);
	
	if ($run_query->num_rows > 0)
    {
		while($row = $run_query->fetch_assoc()) {
        $reader_id = $row["reader_id"];
		$reader_email = $row["reader_email"];
		$reader_fname = $row["reader_fname"];
		$reader_lname = $row["reader_lname"];
		$reader_add = $row["reader_add"];
		$reader_city = $row["reader_city"];
		$reader_state = $row["reader_state"];
		$reader_zip = $row["reader_zip"];
		$reader_phone = $row["reader_phone"];
		$reader_que = $row["reader_que"];
		$reader_ans = $row["reader_ans"];
    }
} 

	else
	{	
			//echo "0 Data";
		echo"<script>alert('Server is under maintenance !')</script>";
	}
	
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Registration</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">Librarian Dashboard</a></h3>
                </div>
                <div class="panel-body">
                    
                        <fieldset>
						<table align="center" class="table">
                            <tr><td>Reader's Id</td><td>:</td><td><?php echo $reader_id;?></td></tr>
							<tr><td>Reader's Email</td><td>:</td><td><?php echo $reader_email;?></td></tr>
							<tr><td>Reader's First Name</td><td>:</td><td><?php echo $reader_fname;?></td></tr>
							<tr><td>Reader's Last Name</td><td>:</td><td><?php echo $reader_lname;?></td></tr>
							<tr><td>Reader's Address</td><td>:</td><td><?php echo $reader_add;?></td></tr>
							<tr><td>Reader's City</td><td>:</td><td><?php echo $reader_city;?></td></tr>
							<tr><td>Reader's State</td><td>:</td><td><?php echo $reader_state;?></td></tr>
							<tr><td>Reader's Zip</td><td>:</td><td><?php echo $reader_zip;?></td></tr>
							<tr><td>Reader's Phone</td><td>:</td><td><?php echo $reader_phone;?></td></tr>
							<tr><td>Reader's Question</td><td>:</td><td><?php echo $reader_que;?></td></tr>
							<tr><td>Reader's Answer</td><td>:</td><td><?php echo $reader_ans;?></td></tr>
						</table>
                            </br>
							<a href="edit_member.php?email=<?php echo $reader_email;?>" class="btn btn-lg btn-success btn-block">Edit</a>
							<a href="librarian_dashboard.php" class="btn btn-lg btn-success btn-block">Done</a>

                        </fieldset>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>