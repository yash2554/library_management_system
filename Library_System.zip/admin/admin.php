<?php
include("../database/db_conection.php");

$check_user_id="select MAX(librarian_id) as maxi FROM librarian";
    $run_user=$dbcon->query($check_user_id);
	if ($run_user->num_rows > 0)
    {
		while($row = $run_user->fetch_assoc()) {
        $librarian_id = $row["maxi"]+1;
		}
	}
	
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Registration</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;

</style>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                </div>
                <div class="panel-body">
                    <form role="form" method="post" action="admin.php">
                        <fieldset>
						
                            <div class="form-group">
                                <input class="form-control" value="<?php echo $librarian_id;?>" name="librarian_id" type="text" pattern="[\d]{1,10}" readonly>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="First name" name="librarian_fname" type="text" pattern="[\w]{2,20}" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Last name" name="librarian_lname" type="text" pattern="[\w]{2,20}" required>
                            </div>

							<div class="form-group">
                                <input class="form-control" placeholder="Library name" name="library_name" type="text" pattern="[\w\s]{2,20}" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Library add" name="library_add" type="text" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Library city" name="library_city" type="text" pattern="[\w\s]{2,20}" required>
                            </div>
								
                            <div class="form-group">
                                <input class="form-control" placeholder="E-mail" name="librarian_email" type="email" pattern="[\w\d]{2,20}\@\w+\.\w+" required autofocus>
                            </div>
							
                            <div class="form-group">
                                <input class="form-control" placeholder="Password" name="librarian_pass" type="password" value="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required>
                            </div>
							
							<div class="form-group">
                                <input class="form-control" placeholder="Repeat Password" name="librarian_pass2" type="password" value="" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required>
                            </div>
							
                            <input class="btn btn-lg btn-success btn-block" type="submit" value="register" name="register" >

                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>

</html>

<?php

if(isset($_POST['register']))
{
	$librarian_id=$_POST['librarian_id'];
    $librarian_fname=$_POST['librarian_fname'];
	$librarian_lname=$_POST['librarian_lname'];
	$librarian_email=$_POST['librarian_email'];
    $librarian_pass=$_POST['librarian_pass'];//same
	$librarian_pass2=$_POST['librarian_pass2'];//same
	
	$lib_name = $_POST['library_name'];
	$lib_add = $_POST['library_add'];
	$lib_city = $_POST['library_city'];
	
	if($librarian_pass2 != $librarian_pass)
	{
	//javascript use for input checking
        echo"<script>alert('Please enter the same password')</script>";
exit();//this use if first is not work then other will not show
    }
	   
	$check_branch_query="select * from branch WHERE lib_name ='$lib_name'";
	$run_branch_query=$dbcon->query($check_branch_query);
	
	if ($run_branch_query->num_rows > 0)
	{
		
	while($row3 = $run_branch_query->fetch_assoc()) {
        $lib_id = $row3["lib_id"];
		echo $author_id;
			}
		}
	else{
	
	$check_lib_id="select MAX(lib_id) as maxi FROM branch";
    $run_lib=$dbcon->query($check_lib_id);
	if ($run_lib->num_rows > 0)
    {
		while($row = $run_lib->fetch_assoc()) {
        $lib_id = $row["maxi"]+1;
		}
		}
	$insert_branch="insert into branch (lib_id,lib_name,lib_add,lib_city) VALUE ('$lib_id','$lib_name','$lib_add','$lib_city')";
    if($dbcon->query($insert_branch))
    {	
		echo"<script>alert('Branch Added Successfully')</script>";
    }
		
	}
	
	$check_email_query="select * from librarian WHERE librarian_email ='$librarian_email' OR librarian_fname ='$librarian_fname' AND librarian_lname='$librarian_lname'";
    $run_query=$dbcon->query($check_email_query);
	
	if ($run_query->num_rows > 0)
    {
echo "<script>alert('Email $librarian_email or $librarian_fname or $librarian_lname is already exist in our database, Please try another one!')</script>";
exit();
    }
	
//insert the reader into the database.
    $insert_lib_branch="insert into lib_branch (lib_id,librarian_id) VALUE ('$lib_id','$librarian_id')";
	$insert_librarian="insert into librarian (librarian_id,librarian_fname,librarian_lname,librarian_email,librarian_pass) VALUE ('$librarian_id','$librarian_fname','$librarian_lname','$librarian_email','$librarian_pass')";
    if($dbcon->query($insert_librarian))
    {	
		if($dbcon->query($insert_lib_branch))
		{
		echo"<script>alert('Registration Successfully')</script>";
		echo"<script>window.open('index.php','_self')</script>";
		}
    }
	else
	{
		echo"<script>alert('Server is under maintenance !')</script>";
	}

}

?>