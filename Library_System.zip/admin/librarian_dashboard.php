<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");
?>
<html>
<head lang="en">
<link rel="icon" href="../database/logo.ico" type="image/ico" />
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="../boot/js/jquery.min.js"></script>
  <script src="../boot/js/bootstrap.min.js"></script>

    <title>
        Librarian-DashBoard
    </title>

<script type="text/javascript" src="../boot/js/jquery.js"></script>
<script type="text/javascript" src="../boot/js-1/jquery.js"></script>
</head>
<style>
    .login-panel {
        margin-top: 37px;
</style>
<body>

	<div class="container" style="width:1024px;">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						
						<h3 class="panel-title"><a href="librarian_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
						
					</div>
					<div class="panel-body">
						<div id="container" align="center"> 
							<table width="100%" border="0" cellpadding="2" cellspacing="2">
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="librarian_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="branch_info.php">Branch Search</a></li>
								<li><a href="search_member.php">Member Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
								
								</td></tr><tr><td></br></br></td></tr>
								<tr><td><a class="list-group-item" href="add_book.php">Add a book copy</a></td></tr>
								<tr><td><a class="list-group-item" href="search_book.php">Search book copy and check its status</a></td></tr>
								<tr><td><a class="list-group-item" href="member_registration.php">Add new reader</a></td></tr>
								<tr><td><a class="list-group-item" href="branch_info.php">Print branch information (name and location)</a></td></tr>
								<tr><td><a class="list-group-item" href="borrow_book.php">Print top 10 most frequent borrowers in a branch and the number of books each has borrowed</a></td></tr>
								<tr><td><a class="list-group-item" href="TopBook.php">Print top 10 most borrowed books in a branch</a></td></tr>
								<tr><td><a class="list-group-item" href="avgfine.php">Find the average fine paid per reader</a></td></tr>
								<tr><td><a class="list-group-item" href="logout.php">Quit</a></td></tr>
							</table>
						</div> <!-- #container -->
					</div>
				</div>
	</div>
</body>
</html>