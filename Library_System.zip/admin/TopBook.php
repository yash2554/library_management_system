<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");
//if(isset($_POST['search_again']))
//{
//    
//	$query=$_POST['title'];
	//echo $query;
	$user=$_SESSION['userid'];
	$check_book="select count(*) as c,b.book_title,br.lib_name from borrow as bo, book as b,branch as br where (bo.book_id=b.book_id and bo.lib_id=br.lib_id) group by bo.book_id order by c desc";   //    echo $check_book;
    $run_book=$dbcon->query($check_book);
	
 
               while($fields = mysqli_fetch_assoc($run_book))
        {
            $values[] = $fields;
         
        }
//        print_r($values);

//}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jqueryi/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Top 10 Borrowers</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>


<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="librarian_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="librarian_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="branch_info.php">Branch Search</a></li>
								<li><a href="search_member.php">Member Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
						
    <div class="container" style="width:1024px;">
    <div class="row">
        <div class="col-md-4 col-md-offset-4" style="width:900px;margin-left: 20px;">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Top 10 Borrowers</h3>
                </div>
                <div class="panel-body">
                 
						<fieldset>
						<table align="" class="col-md-12 table-striped table-condensed cf">
                                                    <tr>
                                                        <th>Book Title</th>
                                                        <th>Branch Name</th>
                                                        <th>No of time Borrowed</th>
                                                     
                                                     
                                                    </tr>
                                                    
						<?php if(isset($value))
						{
							if($values!=null){
                                                    
     foreach ($values as $key => $row) {
    
?>
						
                                                <tr>

    
                                                    <td><?php echo $row['book_title'];?></td>
                                                    <td><?php echo $row['lib_name'];?></td>
                                                    <td><?php echo $row['c'];?></td>
                                                   
                                                    
                                                </tr>
                                            <?php    }
                                                }
						}
                                                else{
                                                
                                                    ?>
                                                <tr>Result Not Found</tr>
                                                <?php
                                                }?>
						</table>
						</br></br></br></br>
						</fieldset>
						
                </div>
            </div>
        </div>
    </div>
</div>
      </div> <!-- #container -->
					</div>
				</div>
	</div>
</body>

</html>