<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: index.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");

$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	<link href="boot/css/style.css" rel="stylesheet" type="text/css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
   .login-panel {
        margin-top: 70px;
	}
	th,td{
		cellspacing:2px;
		cellpadding:2px;
	}
</style>
<body>
<!-- View Cart Box Start -->
<?php

if(isset($_SESSION["cart_products"]) && count($_SESSION["cart_products"])>0)
{
	echo '<div class="cart-view-table-front" id="view-cart">';
	echo '<h3>Your Cart</h3>';
	echo '<form method="post" action="cart_update.php">';
	echo '<table width="100%"  cellpadding="6" cellspacing="0">';
	echo '<tbody>';


	$b = 0;
	foreach ($_SESSION["cart_products"] as $cart_itm)
	{
		$product_name = $cart_itm["book_title"];
		$product_qty = $cart_itm["product_qty"];
		$product_price = $cart_itm["book_isbn"];
		$product_code = $cart_itm["book_id"];
		
		$bg_color = ($b++%2==1) ? 'odd' : 'even'; //zebra stripe
		echo '<tr class="'.$bg_color.'">';
		echo '<td>Qty <input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" readonly/></td>';
		echo '<td>'.$product_name.'</td>';
		echo '<td><input type="checkbox" name="remove_code[]" value="'.$product_code.'" /> Remove</td>';
		echo '</tr>';
	
	}
	echo '<td colspan="4">';
	echo '<button type="submit">Update</button><a href="view_cart.php" class="button">Checkout</a>';
	echo '</td>';
	echo '</tbody>';
	echo '</table>';
	
	$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
	echo '</form>';
	echo '</div>';

}
?>
<!-- View Cart Box End -->


<!-- Products List Start -->
<?php
if(isset($_POST['search']))
{
echo "<div class=\"container\" style=\"width:1024px\">
				<div class=\"login-panel panel panel-success\">
					<div class=\"panel-heading\">
						<h3 class=\"panel-title\"><a href=\"member_dashboard.php\">Welcome -". $_SESSION['username']."</a><p align=\"right\" style=\"font-size:150%;\"><a href=\"logout.php\">Logout</a></p></h3>
					</div>
               <div class=\"panel-body\">
						<div id=\"container\" align=\"center\"> 
							
								<tr><td colspan=\"4\" align=\"left\" align=\"middle\">
								<div style=\"font-size:15px;\">
								
								<nav class=\"navbar navbar-default\">
								<div class=\"container-fluid\">
								<div class=\"navbar-header\">
								<a class=\"navbar-brand\" href=\"member_dashboard.php\">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class=\"nav navbar-nav\"\>
								<li class=\"active\"><a href=\"search_book.php\">Book Search</a></li>
								<li><a href=\"search_publisher.php\">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>";

$query=$_POST['query'];
$results = $dbcon->query("SELECT branch.lib_id,branch.lib_name,book.book_id,book.book_title,book.book_isbn,publisher.publisher_name,author.author_fname,author.author_lname,(book_qty-reserved_copy) as a FROM branch_book,book,branch,publisher,author,book_pub WHERE (author.author_id=book_pub.author_id AND publisher.publisher_id=book_pub.publisher_id AND book.book_id=book_pub.book_id) AND (book.book_id='$query' OR book.book_title like '%".$query."%' OR publisher.publisher_name like '%".$query."%') AND (branch_book.lib_id=branch.lib_id AND branch_book.book_id=book.book_id AND branch_book.reserved_copy<branch_book.book_qty)");
if($results){
//fetch results set as object and output HTML
echo "<form method=\"post\" action=\"cart_update.php\">";
echo "<table align=\"center\" class=\"col-md-12 table-striped table-condensed cf\">
	<tr><th>Book Title</th><th>Book ISBN</th><th>Branch Name</th><th>Author Name</th><th>Publisher Name</th><th>Book Available</th><th>Book Qty</th><th>Reserve Date</th><th>Action</th></tr>";
while($obj = $results->fetch_assoc())
{
echo "<tr><td>".$obj["book_title"]."</td><td>".$obj["book_isbn"]."</td><td>".$obj["lib_name"]."</td><td>".$obj["author_fname"]." ".$obj["author_lname"]."</td><td>".$obj["publisher_name"]."</td><td>".$obj["a"]."</td><td><input type=\"text\" size=\"2\" maxlength=\"2\" name=\"product_qty\" value=\"1\" readonly/></td><td><input class=\"form-control\" placeholder=\"Reserve Date\" name=\"reserve_date\" type=\"date\" /></td><td><input type=\"submit\" class=\"button\" value=\"Checkout\"></td></tr>
	
	<input type=\"hidden\" name=\"book_id\" value=\"".$obj["book_id"]."\" />
	<input type=\"hidden\" name=\"type\" value=\"add\" />
	<input type=\"hidden\" name=\"return_url\" value=\"".$current_url."\" />";
}

echo "
</table></div></div>
	<center><a href=\"search_book.php\" class=\"button\">search again</a></center>
	</br></br>
	</form>";
echo "</div> <!-- #container -->
					</div>
				</div>
	</div>";
}
else
	{	
		echo"<script>alert('No data exist !')</script>";
		echo "<script>window.open('search_publisher.php','_self')</script>";
	}
}
else
{
	echo"<script>window.open('view_cart.php','_self')</script>";
}
?>    
<!-- Products List End -->





</body>
</html>
