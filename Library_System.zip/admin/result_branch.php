<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

if(isset($_POST['search']))
{
	$query=$_POST['query'];
	//echo $query;
	$check_branch="select * FROM branch WHERE branch.lib_city like '%".$query."%' OR branch.lib_name like '%".$query."%'";
      //  echo $check_branch;
    $run_branch=$dbcon->query($check_branch);
	
	if ($run_branch->num_rows > 0)
    {
		echo "<div class=\"container\" style=\"width:1024px;\">
            <div class=\"login-panel panel panel-success\">
                <div class=\"panel-heading\">
                    <h3 class=\"panel-title\"><a href=\"librarian_dashboard.php\">Welcome - ".$_SESSION['username']."</a></h3>
                </div>
                <div class=\"panel-body\">
				<div id=\"container\" align=\"center\"> 
							
								<tr><td colspan=\"4\" align=\"left\" align=\"middle\">
								<div style=\"font-size:15px;\">
								
								<nav class=\"navbar navbar-default\">
								<div class=\"container-fluid\">
								<div class=\"navbar-header\">
								<a class=\"navbar-brand\" href=\"librarian_dashboard.php\">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class=\"nav navbar-nav\">
								<li class=\"active\"><a href=\"search_book.php\">Book Search</a></li>
								<li><a href=\"branch_info.php\">Branch Search</a></li>
								<li><a href=\"search_member.php\">Member Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
				<form role=\"form\" method=\"post\" action=\"branch_info.php\">
						<fieldset>";
		echo "<table align=\"center\" class=\"col-md-12 table-striped table-condensed cf\">
		<tr><th>Library Id</th><th>Library Name</th><th>Library Add</th><th>Library City</th></tr>";
		    while($fields = mysqli_fetch_assoc($run_branch))
        {
            $row[] = $fields;
         
        }
        if($row!=NULL){
        $lib_id=$row[0]['lib_id'];
		$lib_name=$row[0]['lib_name'];
		$lib_add=$row[0]['lib_add'];
		$lib_city=$row[0]['lib_city'];
//		$book_qty=$row[0]['book_qty'];
//		$reserved_copy=$row[0]['reserved_copy'];
//		$book_id=$row[0]['book_id'];
//		$book_title=$row[0]['book_title'];
//		$book_isbn=$row[0]['book_isbn'];
//		$book_date=$row[0]['book_date'];
		
		echo "<tr><td>".$lib_id."</td><td>".$lib_name."</td><td>".$lib_add."</td><td>".$lib_city."</td></tr>";
        }
		echo "</table>";
		echo "</br></br></br></br>
						</fieldset>
						</br></br></br></br>
						<input class=\"btn btn-lg btn-success btn-block\" type=\"submit\" value=\"search again\" name=\"search_again\" >
					</form>
                </div>
    </div>
</div>";
} 

	else
	{	
		echo"<script>alert('No data exist !')</script>";
		echo "<script>window.open('branch_info.php','_self')</script>";
	}
}
else{
	echo"<script>window.open('branch_info.php','_self')</script>";
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>


						
						

</body>

</html>