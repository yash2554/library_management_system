<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

if(isset($_POST['search']))
{
	$query=$_POST['query'];
	//echo $query;
	$check_member="select reader.reader_id,reader.reader_fname,reader.reader_lname,reader.reader_email,reader.reader_add,reader.reader_city,reader.reader_state,reader.reader_zip,reader.reader_phone FROM reader WHERE reader.reader_id = '$query'";
    $run_member=$dbcon->query($check_member);
	
	if ($run_member->num_rows > 0)
    {
		echo "<div class=\"container\" style=\"width:1024px;\">
            <div class=\"login-panel panel panel-success\">
                <div class=\"panel-heading\">
                    <h3 class=\"panel-title\"><a href=\"librarian_dashboard.php\">&lt;&nbsp;Librarian Dashboard</a></h3>
                </div>
                <div class=\"panel-body\">
				<form role=\"form\" method=\"post\" action=\"search_member.php\">
						<fieldset>";
		echo "<table align=\"center\" class=\"col-md-12 table-striped table-condensed cf\">
		<tr><th>Reader Id</th><th>Reader Fname</th><th>Reader Lname</th><th>Reader Email</th><th>Reader Add</th><th>Reader City</th><th>Reader State</th><th>Reader Zip</th><th>Reader Phone</th></tr>";
		
		while($row = $run_member->fetch_assoc()) {
        $reader_id=$row['reader_id'];
		$reader_fname=$row['reader_fname'];
		$reader_lname=$row['reader_lname'];
		$reader_email=$row['reader_email'];
		$reader_add=$row['reader_add'];
		$reader_city=$row['reader_city'];
		$reader_state=$row['reader_state'];
		$reader_zip=$row['reader_zip'];
		$reader_phone=$row['reader_phone'];
		
		echo "<tr><td>".$reader_id."</td><td>".$reader_fname."</td><td>".$reader_lname."</td><td>".$reader_email."</td><td>".$reader_add."</td><td>".$reader_city."</td><td>".$reader_state."</td><td>".$reader_zip."</td><td>".$reader_phone."</td></tr>";
    }
		echo "</table>";
		echo "</br></br></br></br>
						</fieldset>
						</br></br></br></br>
						<input type=\"hidden\" name=\"reader_email\" value=\"$reader_email\">
						<input class=\"btn btn-lg btn-success btn-block\" type=\"submit\" value=\"edit\" name=\"edit\">
						<input class=\"btn btn-lg btn-success btn-block\" type=\"submit\" value=\"search again\" name=\"search_again\" >
					</form>
                </div>
    </div>
</div>";
} 

	else
	{	
		echo"<script>alert('No data exist !')</script>";
		echo "<script>window.open('search_member.php','_self')</script>";
	}
}
else{
	echo"<script>window.open('search_member.php','_self')</script>";
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>


						
						

</body>

</html>