<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("../database/db_conection.php");

if(isset($_POST['search']))
{
	$query=$_POST['title'];
	//echo $query;
	$check_book="select book.book_id,book.book_title,book.book_isbn,book.book_date,author.author_id,author.author_fname,author.author_lname,author.author_add,author.author_city,publisher.publisher_id,publisher.publisher_name,publisher.publisher_add,publisher.publisher_city,branch_book.lib_id,branch_book.book_qty,branch_book.reserved_copy FROM book,author,publisher,book_pub,branch_book WHERE book.book_id = book_pub.book_id AND publisher.publisher_id= book_pub.publisher_id AND author.author_id = book_pub.author_id AND book.book_id = branch_book.book_id AND book.book_title like '%$query%'" ;
//        echo $check_book;
    $run_book=$dbcon->query($check_book);
	
 
               while($fields = mysqli_fetch_assoc($run_book))
        {
            $values[] = $fields;
         
        }
}

else{
	echo"<script>window.open('search_book.php','_self')</script>";
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="../boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>

    <div class="container" style="width:1024px;">
            <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">&lt;&nbsp;Librarian Dashboard</a></h3>
                </div>
                <div class="panel-body">
                 
				<form role="form" method="post" action="search_book.php">
						<fieldset>
						<table align="center" class="col-md-12 table-striped table-condensed cf">
						<tr><th>Book's ID</th>
						<th>Book's Title</th>
						<th>Book' ISBN</th>
						<th>Publication Date</th>
						<th>Branch Id</th>
						<th>Book Qty</th>
						<th>Reserved Book Copy</th>
						<th>Author's Name</th>
						<th>Author's Address</th>
                        <th>Author's City</th>
                        <th>Publisher's Name</th>
						<th>Publisher's Address</th>
                        <th>Publisher's City</th></tr>
						<?php if($values!=null){
                                                    
     foreach ($values as $key => $row) {
    
}?>
						
                                                <tr>

    
                                                    <td><?php echo $row['book_id'];?></td>
                                                    <td><?php echo $row['book_title'];?></td>
                                                    <td><?php echo $row['book_isbn'];?></td>
                                                    <td><?php echo $row['book_date'];?></td>
                                                    <td><?php echo $row['lib_id'];?></td>
                                                    <td><?php echo $row['book_qty']?></td>
                                                    <td><?php echo $row['reserved_copy'];?></td>
                                                    <td><?php echo $row['author_fname']." ".$row['author_lname'];?></td>
                                                    <td><?php echo $row['author_add'];?></td>
                                                    <td><?php echo $row['author_city'];?></td>
                                                    <td><?php echo $row['publisher_name'];?></td>
                                                    <td><?php echo $row['publisher_add'];?></td>
                                                    <td><?php echo $row['publisher_city'];?></td>
                                                    <!--<td><?php echo $row['librarian_id'];?></td>-->
                                                </tr>
                                            <?php    }
                                                else{
                                                
                                                    ?>
                                                <tr>Result Not Found</tr>
                                                <?php
                                                }?>
						</table>
						</br></br>
						</fieldset>
						</br></br>
						<input class="btn btn-lg btn-success btn-block" type="submit" value="search again" name="search_again" >
					</form>
           </div>
    </div>
</div>

</body>

</html>