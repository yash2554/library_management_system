<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: member_dashboard.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");

if(isset($_POST['book_id'])){
    $book_id=$_POST['book_id'];
    $lib_id=$_POST['lib_id'];
	
   // $query=$_POST['title'];
	//echo $query;
	$date = $_POST['reserve_date'];
	//echo $date;
    $reader_id=$_SESSION['user_id'];
	$return_date = date('Y-m-d', strtotime($date. ' + 15 days'));
	//echo $return_date;
	$check_book="insert into borrow(reader_id,book_id,lib_id,reserve_date,due_date) values ('$reader_id','$book_id','$lib_id','$date','$return_date')";
    // echo $check_book;
        if($dbcon->query($check_book))
		{	
		echo"<script>alert('Book Reserved Successfully')</script>";
		}
	else{
		echo"<script>alert('Error')</script>";
		}
	}
	else{
		echo"<script>window.open('book_reserve.php','_self')</script>";
	}
    

?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search for Book</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;

</style>
<body>
<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="member_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
                                                                  <table align="center" class="col-md-12 table-striped table-condensed cf">
						
                                                                            <tr>
                                                                                <td> You Book Has Been Issued</td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td> Reserve Date:</td>
                                                                                <td> <?php $date=date("m/d/y"); echo $date;?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td> Expire Date:</td>
                                                                                <td> <?php 
                                                                            echo date('m/d/y', strtotime("+10 days"));?></td>
                                                                            </tr>
                                                                            
                                                                        </table>
                                                                 <?php
                                                              
                                                                   ?>
                                                                        <!--<a href="book_return.php"> <input class="btn btn-lg btn-success btn-block" type="button" value="View Issued Book" ></a>-->
				
               </div> <!-- #container -->
					</div>
				</div>
	</div>

</body>

</html>