<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: member_dashboard.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search for Book</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;

</style>
<body>
<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="member_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
                                                                  <table align="center" class="col-md-12 table-striped table-condensed cf">
                                               
						<tr>
						<th>No.</th>
						<th>Book's Title</th>
						<th>Book' ISBN</th>
						<th>Issue Date</th>
						<th>Due Date</th>
						<th>Days</th>
						<th>Fine</th>
						</tr>
						<?php
	$reader_id=$_SESSION['user_id'];
	$check_book="select book.book_title,book.book_isbn,borrow.issue_date,borrow.return_date,borrow.due_date,borrow.book_id,borrow.lib_id from Book, Borrow where book.book_id=borrow.book_id and borrow.reader_id=".$reader_id." and return_date IS NULL" ;
    // echo $check_book;
    $run_book=$dbcon->query($check_book);
	$today = date("y-m-d");
	//echo $today."</br>";
     if($run_book->num_rows > 0)
		{
			$no =0;
        while($row = $run_book->fetch_assoc()){
			$no=$no+1;
		if ($row['return_date']==NULL & $row['issue_date']!=NULL){
            if($today<=date('y-m-d', strtotime($row['due_date']))){
                $fine_book=0;
			echo "<td>".$no."</td>
				<td>".$row['book_title']."</td>
				<td>".$row['book_isbn']."</td>
                <td>".$row['issue_date']."</td>
				<td>".$row['due_date']."</td>
				<td>0</td>
				<td>".$fine_book."</td>
                </tr>";
            }
            else{
				$fine_time= date('y-m-d', strtotime($row['due_date']));
				//echo $fine_time."</br>";
				$days = (strtotime($today) - strtotime($fine_time))/86400;
				//echo $days."</br>";
                $fine_book=$days*20;
			echo "<td>".$no."</td>
				<td>".$row['book_title']."</td>
				<td>".$row['book_isbn']."</td>
                <td>".$row['issue_date']."</td>
				<td>".$row['due_date']."</td>
				<td>".$days."</td>
				<td>&#162; ".$fine_book."</td>
                </tr>";
				}
			}
        }
     }
	 else{
	echo "<script>alert('First Checkout Book')</script>";
	echo "<script>window.open('member_dashboard.php','_self')</script>";
  }
	?>
						</table>
						</br></br>
				
               </div> <!-- #container -->
					</div>
				</div>
	</div>

</body>

</html>