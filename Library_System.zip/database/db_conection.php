<?php

ini_set('max_execution_time', 600);   
	
$dbcon = new mysqli("localhost","root","","library_system");

if ($dbcon->connect_error) {
    die("Connection failed: " . $dbcon->connect_error);
} 

?>