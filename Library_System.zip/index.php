<html>
<head lang="en">
<link rel="icon" href="" type="image/ico" />
<meta charset="UTF-8">
<link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<title>Home</title>
</head>
<style>
    .home-panel {
        margin-top: 70px;
	}
		p{
			color:yellow;
		}
</style>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="home-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title" align="center"><a href="index.php"><p>Library Management System</p></a></h3>
                </div>
                <div class="panel-body">
						<center>
						
						</br>
						<a class="btn btn-lg btn-success btn-block" href="member_login.php">Member Login</a>
						</br>
						<a class="btn btn-lg btn-success btn-block" href="admin/librarian_login.php">Librarian Login</a>
						</br></br>
						<img src="images/bg.png" height="150" width="260" style="opacity:0.8;"/>
						</center>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>