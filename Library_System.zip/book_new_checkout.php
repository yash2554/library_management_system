<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: member_dashboard.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");
if(isset($_POST['search_again']))
{
	
}	
	$user_id=$_SESSION['user_id'];
	echo $user_id;
 	$check_user="select * from borrow WHERE reader_id='$user_id'";

    $run=$dbcon->query($check_user);

    if($run->num_rows > 9)
    {
		   echo "<script>window.open('book_checkout_cart.php','_self')</script>";
    }
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search for Book</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>
<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="member_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
						<form role="form" method="post" action="checkout_book_list.php">
						<fieldset>
						<input type="text" name="title" class="form-control input-lg" placeholder="Enter Name of the Book" required/>
						</br></br>
                        <input class="btn btn-lg btn-success btn-block" type="submit" value="search" name="search" >
						</fieldset>
						</form>
               </div> <!-- #container -->
					</div>
				</div>
	</div>

</body>

</html>