<?php
session_start();
if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");

if(isset($_POST['return_button'])){
		$reader_id=$_SESSION['user_id'];
		$book_qty=$_POST['book_qty'];
		$lib_id=$_POST['lib_id'];
		$avail=$book_qty+1;
		echo $avail;
		//$book_id=$_POST['book_id'];
		
		$check_branch_book ="update branch_book set branch_book.book_qty='".$avail."' where (branch_book.lib_id='".$lib_id."' and branch_book.book_id='".$_POST['book_id']."')";
        $check_book="update borrow set borrow.return_date='".date('y-m-d h:i:s')."',fine='".$_POST['fine']."' where reader_id='".$reader_id."'
 and book_id='".$_POST['book_id']."'";
     //echo $check_book;
        if($dbcon->query($check_book) && $dbcon->query($check_branch_book))
		{	
		echo"<script>alert('Book Return Successfully')</script>";
                echo "<script>window.open('book_return.php','_self')</script>";
		}
	else{
		echo"Error";
		}
  }
?>

<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>
	
    <div class="container" style="width:1024px;">
    <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">&lt;&nbsp;Member Dashboard</a></h3>
                </div>
               <div class="panel-body">
						<div id="container" align="center"> 
                                                                <tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
						
               </div> <!-- #container -->
					</div>
                <div class="panel-body">
                 
				<!--<form role="form" method="post" action="search_book.php">-->
						<fieldset>
						<table align="center" class="col-md-12 table-striped table-condensed cf">
                                               
						<tr>
						<th>No.</th>
						<th>Book's Title</th>
						<th>Book' ISBN</th>
						<th>Issue Date</th>
						<th>Due Date</th>
						<th>Fine</th>
						<th>Action</th>
						</tr>
						<?php
	$reader_id=$_SESSION['user_id'];
	$check_book="select book.book_title,book.book_isbn,borrow.issue_date,borrow.return_date,borrow.due_date,borrow.book_id,borrow.lib_id,branch_book.book_qty from Book, Borrow,branch_book where (book.book_id=borrow.book_id AND borrow.book_id=branch_book.book_id AND borrow.lib_id=branch_book.lib_id) AND borrow.reader_id=".$reader_id." and borrow.return_date IS NULL" ;
    // echo $check_book;
    $run_book=$dbcon->query($check_book);
	$today = date("y-m-d");
	//echo $today."</br>";
     if($run_book->num_rows > 0)
		{
			$no =0;
        while($row = $run_book->fetch_assoc()){
			$no=$no+1;
		if ($row['issue_date']!=NULL AND $row['due_date']!=NULL){
            if($today<=date('y-m-d', strtotime($row['due_date']))){
                $fine_book=0;
				echo "<form action=\"book_return.php\" method=\"post\">
			<tr><input type=\"hidden\" name=\"book_id\" value=\"".$row['book_id']."\"><input type=\"hidden\" name=\"lib_id\" value=\"".$row['lib_id']."\"><input type=\"hidden\" name=\"fine\" value=\"".$fine_book."\"><input type=\"hidden\" name=\"book_qty\" value=\"".$row['book_qty']."\">";
			echo "<td>".$no."</td>
				<td>".$row['book_title']."</td>
				<td>".$row['book_isbn']."</td>
                <td>".$row['issue_date']."</td>
				<td>".$row['due_date']."</td>
				<td>".$fine_book."</td>
				<td><input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" value=\"Return\" name=\"return_button\"></td>
                </form>
                </tr>";
            }
            else{
				$fine_time= date('y-m-d', strtotime($row['due_date']));
				//echo $fine_time."</br>";
				$days = (strtotime($today) - strtotime($fine_time))/86400;
				//echo $days."</br>";
                $fine_book=$days*20;
				echo "<form action=\"book_return.php\" method=\"post\">
			<tr><input type=\"hidden\" name=\"book_id\" value=\"".$row['book_id']."\"><input type=\"hidden\" name=\"lib_id\" value=\"".$row['lib_id']."\"><input type=\"hidden\" name=\"fine\" value=\"".$fine_book."\"><input type=\"hidden\" name=\"book_qty\" value=\"".$row['book_qty']."\">";
			echo "<td>".$no."</td>
				<td>".$row['book_title']."</td>
				<td>".$row['book_isbn']."</td>
                <td>".$row['issue_date']."</td>
				<td>".$row['due_date']."</td>
				<td>&#162; ".$fine_book."</td>
				<td><input type=\"submit\" class=\"btn btn-lg btn-success btn-block\" value=\"Return\" name=\"return_button\"></td>
                </form>
                </tr>";
				}
			}
        }
     }
	 else{
	echo "First Checkout Book";
	echo "<script>window.open('member_dashboard.php','_self')</script>";
  }
	?>
						</table>
						</br></br>
						</fieldset>
						</br></br>
           </div>
    </div>
</div>
</body>
</html>