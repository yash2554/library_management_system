<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: index.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");

if(isset($_POST['search']))
{
	$query=$_POST['query'];
	$check_pub="select book.book_id,book.book_title,book.book_isbn,book.book_date,publisher.publisher_name,branch_book.book_qty,branch.lib_name,branch.lib_add,branch.lib_city FROM book,book_pub,publisher,branch_book,branch WHERE (book.book_id=book_pub.book_id AND branch.lib_id=branch_book.lib_id AND branch_book.book_id=book.book_id AND book_pub.publisher_id=publisher.publisher_id) AND (publisher.publisher_id = '$query' OR publisher.publisher_name like '%".$query."%')";
    $run_pub=$dbcon->query($check_pub);
	
	if ($run_pub->num_rows > 0)
    {
		echo "<div class=\"container\" style=\"width:1024px\">
				<div class=\"login-panel panel panel-success\">
					<div class=\"panel-heading\">
						<h3 class=\"panel-title\"><a href=\"member_dashboard.php\">Welcome - ". $_SESSION['username']."</a><p align=\"right\" style=\"font-size:150%;\"><a href=\"logout.php\">Logout</a></p></h3>
					</div>
               <div class=\"panel-body\">
						<div id=\"container\" align=\"center\"> 
							
								<tr><td colspan=\"4\" align=\"left\" align=\"middle\">
								<div style=\"font-size:15px;\">
								
								<nav class=\"navbar navbar-default\">
								<div class=\"container-fluid\">
								<div class=\"navbar-header\">
								<a class=\"navbar-brand\" href=\"member_dashboard.php\">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class=\"nav navbar-nav\"\>
								<li class=\"active\"><a href=\"search_book.php\">Book Search</a></li>
								<li><a href=\"search_publisher.php\">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
				<form role=\"form\" method=\"post\" action=\"search_publisher.php\">
						<fieldset>";
		echo "<table align=\"center\" class=\"col-md-12 table-striped table-condensed cf\">
		<tr><th>Book Id</th><th>Book Title</th><th>Book ISBN</th><th>Publication Date</th><th>Publisher Name</th><th>Book Qty</th><th>Branch Name</th><th>Branch Address</th><th>Branch City</th></tr>";
		
		while($row = $run_pub->fetch_assoc()) {
        $book_id=$row['book_id'];
		$book_title=$row['book_title'];
		$book_isbn=$row['book_isbn'];
		$book_date=$row['book_date'];
		$publisher_name=$row['publisher_name'];
		$book_qty=$row['book_qty'];
		$lib_name=$row['lib_name'];
		$lib_add=$row['lib_add'];
		$lib_city=$row['lib_city'];
		
		echo "<tr><td>".$book_id."</td><td>".$book_title."</td><td>".$book_isbn."</td><td>".$book_date."</td><td>".$publisher_name."</td><td>".$book_qty."</td><td>".$lib_name."</td><td>".$lib_add."</td><td>".$lib_city."</td></tr>";
    }

	echo "</table>";
		echo "</br></br></br></br>
						</fieldset>
						</br></br>
						<input class=\"btn btn-lg btn-success btn-block\" type=\"submit\" value=\"search again\" name=\"search_again\" >
					</form>
                </div> <!-- #container -->
					</div>
				</div>
	</div>";
} 

	else
	{	
		echo"<script>alert('No data exist !')</script>";
		echo "<script>window.open('search_publisher.php','_self')</script>";
	}
}
else{
	echo"<script>window.open('search_publisher.php','_self')</script>";
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
		
</style>
<body>

</body>

</html>