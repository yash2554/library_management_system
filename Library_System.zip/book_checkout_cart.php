<?php
session_start();

if(!$_SESSION['username'])
{
	header("Location: member_dashboard.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");


?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search for Book</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>
<div class="container" style="width:1024px">
				<div class="login-panel panel panel-success">
					<div class="panel-heading">
						<h3 class="panel-title"><a href="member_dashboard.php">Welcome - <?php echo $_SESSION['username'];?></a><p align="right" style="font-size:150%;"><a href="logout.php">Logout</a></p></h3>
					</div>
               <div class="panel-body">
						<div id="container" align="center"> 
							
								<tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
								</div>
								
								<table align="center" class="col-md-12 table-striped table-condensed cf" cellspacing="4" cellpadding="5">
<?php
		$user_id=$_SESSION['user_id'];
		$check_borrow="SELECT book.book_id,book.book_title,branch.lib_name,branch.lib_id,borrow.reserve_date,borrow.issue_date,borrow.due_date FROM borrow,branch,book WHERE borrow.reader_id='$user_id' AND (book.book_id=borrow.book_id AND branch.lib_id=borrow.lib_id) ORDER BY book.book_id";
		$run_borrow=$dbcon->query($check_borrow);
		$date=date("y-m-d h:i:s");
		$due_date=date("y-m-d h:i:s", strtotime("+20 days"));
		//echo $due_date;
		if($run_borrow->num_rows > 0)
		{
		echo "<tr><th>No</th><th>Book Title</th><th>Branch Name</th><th>Reserved Date</th><th>Checkout Date</th><th>Action</th></tr>";
		
		$no =0;
		while($row = $run_borrow->fetch_assoc()) {
			$no = $no+1;
			if($row['reserve_date']!='' AND $row['issue_date']==NULL){
				echo "<form role=\"form\" method=\"post\" action=\"book_checkout.php\">";
		 echo "<input type=\"hidden\" value=\"".$row['book_id']."\" name=\"book_id\" /><input type=\"hidden\" value=\"".$row['lib_id']."\" name=\"lib_id\" /><input type=\"hidden\" value=\"".$date."\" name=\"issue_date\" /><input type=\"hidden\" value=\"".$due_date."\" name=\"due_date\" />";
         echo "<tr><td>".$no."</td><td>".$row['book_title']."</td><td>".$row['lib_id']."</td><td>".$row['reserve_date']."</td><td>".$date."</td><td><input class=\"btn btn-lg btn-success btn-block\" name=\"checkout\" value=\"checkout\" type=\"submit\"/></td></tr>";
		 echo "</form>";
			}
		}
		}
		else{
			//echo"Checkout cart is empty</br>";
			echo "Please add book in cart";
			echo "<script>window.open('book_new_checkout.php','_self')</script>";
		}    

?>									                                          
               </table>
			   </div> <!-- #container -->
			</div>
			
			<?php
		$user_id=$_SESSION['user_id'];
		$check="SELECT borrow.issue_date,borrow.reserve_date,borrow.return_date,borrow.due_date FROM borrow WHERE borrow.reader_id='$user_id'";
		$run=$dbcon->query($check);
				
		if($run->num_rows > 0){
			while($row = $run->fetch_assoc()) {
				$c=$row['issue_date'];
				$d=$row['return_date'];
				
				}
				if($c!='' && $d==NULL){
			echo "</br><a href=\"book_return.php\" class=\"btn btn-lg btn-success btn-block\" style=\"width:20%;\">Return Book</a></br>";
		}
	}
		else{
			echo "<script>window.open('member_dashboard.php','_self')</script>";
		}   
		?>
				</div>
	</div>

</body>

</html>