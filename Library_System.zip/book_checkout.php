<?php
session_start();
if(!$_SESSION['username'])
{
	header("Location: ../index.php");//redirect to login page to secure the welcome page without login access.
}
include("database/db_conection.php");

if(isset($_POST['new_checkout_book']))
{	$reader_id=$_SESSION['user_id'];
	$book_id = $_POST['book_id'];
	$lib_id = $_POST['lib_id'];
	$reserved_copy=$_POST['reserved_copy'];
	$book_qty=$_POST['book_qty'];
	$avail_book=$book_qty-1;
	echo $avail_book;
	
	$date=date("y-m-d h:i:sa");
	$due_date=date("y-m-d h:i:s", strtotime("+20 days"));
	
	$insert_new_checkout = "insert into borrow (reader_id,book_id,lib_id,issue_date,due_date,fine) VALUE ('$reader_id','$book_id','$lib_id','$date','$due_date',0)";
	$branch_book_update="UPDATE branch_book SET book_qty='$avail_book',reserved_copy='$reserved_copy' WHERE (book_id='$book_id' AND lib_id='$lib_id')";
    

if ($dbcon->query($insert_new_checkout) == TRUE && $dbcon->query($branch_book_update) === TRUE) {
    echo "<script>alert('Book Checkout successfully')</script>";
	//echo "<script>window.open('book_checkout_cart.php','_self')</script>";
	
} else {
    echo "Error updating record: " . $dbcon->error;
}

}
if(isset($_POST['checkout']))
{	$user_id=$_SESSION['user_id'];
	$book_id = $_POST['book_id'];
	$lib_id = $_POST['lib_id'];
	$issue_date = $_POST['issue_date'];
	$due_date = $_POST['due_date'];
	
	$sql = "UPDATE borrow SET issue_date='$issue_date',due_date='$due_date' WHERE (reader_id='$user_id' AND book_id='$book_id' AND lib_id='$lib_id')";

if ($dbcon->query($sql) === TRUE) {
    echo "<script>alert('Book Checkout successfully')</script>";
	echo "<script>window.open('book_checkout_cart.php','_self')</script>";
	
} else {
    echo "Error updating record: " . $dbcon->error;
}

}
if(isset($_POST['search']))
{
	$query=$_POST['title'];
	//echo $query;
	$check_book="select book.book_id,book.book_title,book.book_isbn,book.book_date,author.author_id,author.author_fname,author.author_lname,author.author_add,author.author_city,publisher.publisher_id,publisher.publisher_name,publisher.publisher_add,publisher.publisher_city,branch_book.lib_id,branch_book.book_qty,branch_book.reserved_copy,branch.lib_name FROM branch,book,author,publisher,book_pub,branch_book WHERE book.book_id = book_pub.book_id AND publisher.publisher_id=book_pub.publisher_id AND author.author_id = book_pub.author_id AND book.book_id = branch_book.book_id AND book.book_title like '%$query%' and branch_book.lib_id=branch.lib_id" ;
     // echo $check_book;
    $run_book=$dbcon->query($check_book);
	
               while($fields = mysqli_fetch_assoc($run_book))
        {
            $values[] = $fields;
         
        }
}
else{
	echo"<script>window.open('search_book.php','_self')</script>";
}
?>
<html>
<head lang="en">
    <meta charset="UTF-8">
		<link rel="icon" href="" type="image/ico" />
    <link type="text/css" rel="stylesheet" href="boot/css/bootstrap.css">
	
	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	
    <title>Search Result</title>
</head>
<style>
    .login-panel {
        margin-top: 70px;
	}
</style>
<body>
	
    <div class="container" style="width:1024px;">
    <div class="login-panel panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><a href="librarian_dashboard.php">&lt;&nbsp;Member Dashboard</a></h3>
                </div>
               <div class="panel-body">
						<div id="container" align="center"> 
                                                                <tr><td colspan="4" align="left" align="middle">
								<div style="font-size:15px;">
								<nav class="navbar navbar-default">
								<div class="container-fluid">
								<div class="navbar-header">
								<a class="navbar-brand" href="member_dashboard.php">&lt;&nbsp;DashBoard</a>
								</div>
								<ul class="nav navbar-nav">
								<li class="active"><a href="search_book.php">Book Search</a></li>
								<li><a href="search_publisher.php">Publisher Search</a></li>
								</ul>
								</div>
								</nav>
						
               </div> <!-- #container -->
					</div>
                <div class="panel-body">
                 
				<!--<form role="form" method="post" action="search_book.php">-->
						<fieldset>
						<table align="center" class="col-md-12 table-striped table-condensed cf">
                                               
						<tr><th>Book's ID</th>
						<th>Book's Title</th>
						<th>Book' ISBN</th>
						<th>Publication Date</th>
						<th>Branch Name</th>
						<th>Book Qty</th>
						<th>Reserved Book Copy</th>
						<th>Author's Name</th>			
                                                <th>Publisher's Name</th>
                                                <th>Action</th>
						</tr>
						<?php if(isset($values)){
                                                    
                                                foreach ($values as $key => $row) {
    
                                                    ?>
                                                     <form action="checkoutBook_final.php" method="post">
                                                  <tr>
                                                  <input type="hidden" name="book_id" value="<?php echo $row['book_id'];?>">
                                                  <input type="hidden" name="lib_id" value="<?php echo $row['lib_id'];?>">
                                                  
                                                  
                                                    <td><?php echo $row['book_id'];?></td>
                                                    <td><?php echo $row['book_title'];?></td>
                                                    <td><?php echo $row['book_isbn'];?></td>
                                                    <td><?php echo $row['book_date'];?></td>
                                                    <td><?php echo $row['lib_name'];?></td>
                                                    <td><?php echo $row['book_qty']?></td>
                                                    <td><?php echo $row['reserved_copy'];?></td>
                                                    <td><?php echo $row['author_fname']." ".$row['author_lname'];?></td>
                                                    <td><?php echo $row['publisher_name'];?></td>
                                                    
                                                    <td><input type="submit" class="btn btn-lg btn-success btn-block" value="Book" name="submit_book"></td>
                                                    </form>
                                                </tr>
                                            <?php    }
                                                }
                                                else{
                                                
                                                    ?>
                                                <tr>Result Not Found</tr>
                                                <?php
                                                }?>
						</table>
						
						</br></br>
						</fieldset>
						</br></br>
<!--						<input class="btn btn-lg btn-success btn-block" type="submit" value="search again" name="search_again" >
					</form>-->
           </div>
    </div>
</div>
</body>
</html>